<?php
session_start();
include("db.php");
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>About Us - WEAR ZONE</title>

    <style>

        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background: #f5f5f5;
            color: #222;
        }

        /* ================= NAVBAR ================= */

        .navbar {
            background: #111;
            padding: 18px 40px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .logo {
            color: white;
            font-size: 24px;
            font-weight: bold;
        }

        .red {
            color: red;
        }

        .navbar a {
            color: white;
            text-decoration: none;
            margin-left: 25px;
            font-size: 15px;
            transition: 0.3s;
        }

        .navbar a:hover {
            color: red;
        }

        /* ================= ABOUT SECTION ================= */

        .about {
            width: 90%;
            max-width: 1000px;
            margin: 50px auto;
            background: white;
            padding: 45px;
            border-radius: 15px;
            box-shadow: 0 5px 20px rgba(0, 0, 0, 0.12);
            text-align: center;
        }

        .about h1 {
            font-size: 38px;
            margin: 0 0 20px;
        }

        .about h1 span {
            color: red;
        }

        .about > p {
            color: #555;
            font-size: 17px;
            line-height: 1.8;
            margin: 10px auto;
            max-width: 850px;
        }

        /* ================= FEATURES ================= */

        .features {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 20px;
            margin-top: 35px;
        }

        .feature {
            padding: 25px;
            background: #f7f7f7;
            border-radius: 10px;
            transition: 0.3s;
        }

        .feature:hover {
            transform: translateY(-5px);
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
        }

        .feature h3 {
            margin: 12px 0;
            font-size: 20px;
        }

        .feature p {
            font-size: 15px;
            color: #555;
            line-height: 1.6;
            margin: 0;
        }

        .icon {
            font-size: 40px;
        }

        /* ================= BUTTON ================= */

        .shop-btn {
            display: inline-block;
            margin-top: 30px;
            padding: 13px 40px;
            background: #111;
            color: white;
            text-decoration: none;
            border-radius: 6px;
            transition: 0.3s;
        }

        .shop-btn:hover {
            background: red;
        }

        /* ================= MOBILE ================= */

        @media (max-width: 700px) {

            .navbar {
                padding: 15px 20px;
                flex-direction: column;
                gap: 15px;
            }

            .navbar a {
                margin-left: 10px;
                margin-right: 10px;
                font-size: 14px;
            }

            .about {
                width: 92%;
                padding: 25px 18px;
                margin: 30px auto;
            }

            .about h1 {
                font-size: 30px;
            }

            .about > p {
                font-size: 15px;
            }

            .features {
                grid-template-columns: 1fr;
            }

            .feature {
                padding: 20px;
            }

        }

    </style>

</head>

<body>

<!-- ================= NAVBAR ================= -->

<div class="navbar">

    <div class="logo">
        WEAR <span class="red">ZONE</span>
    </div>

    <div>

        <a href="index.php">Home</a>

        <a href="about.php">About Us</a>

        <a href="contact.php">Contact</a>

    </div>

</div>


<!-- ================= ABOUT SECTION ================= -->

<section class="about">

    <h1>
        About <span>WEAR ZONE</span>
    </h1>

    <p>
        Welcome to <b>WEAR ZONE</b>, your online destination
        for stylish and modern fashion.
        We provide quality clothing products with a simple
        and convenient online shopping experience.
    </p>

    <p>
        Our goal is to make fashion shopping easy,
        affordable and enjoyable for every customer.
        Browse our collection, add your favorite products
        to your cart or wishlist, and place your order easily.
    </p>


    <!-- ================= FEATURES ================= -->

    <div class="features">

        <div class="feature">

            <div class="icon">
                👕
            </div>

            <h3>
                Quality Fashion
            </h3>

            <p>
                Stylish and quality clothing products
                for different occasions.
            </p>

        </div>


        <div class="feature">

            <div class="icon">
                🛒
            </div>

            <h3>
                Easy Shopping
            </h3>

            <p>
                Add products to your cart and
                checkout easily.
            </p>

        </div>


        <div class="feature">

            <div class="icon">
                🚚
            </div>

            <h3>
                Easy Order Management
            </h3>

            <p>
                Track your orders and check
                your order status easily.
            </p>

        </div>

    </div>


    <!-- ================= SHOP BUTTON ================= -->

    <a href="index.php" class="shop-btn">
        🛍️ Start Shopping
    </a>

</section>

</body>

</html>