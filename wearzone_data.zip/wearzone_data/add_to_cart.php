```php
<?php

session_start();
include("db.php");

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

if (!isset($_GET['id']) || empty($_GET['id'])) {
    header("Location: index.php");
    exit();
}

$user_id = (int)$_SESSION['user_id'];
$product_id = (int)$_GET['id'];
$size = isset($_GET['size']) ? trim($_GET['size']) : '';

$product = mysqli_query(
    $conn,
    "SELECT id, price, size_prices
     FROM products
     WHERE id='$product_id'
     LIMIT 1"
);

if (!$product || mysqli_num_rows($product) == 0) {
    echo "<script>
            alert('Product not found!');
            window.location='index.php';
          </script>";
    exit();
}

$row = mysqli_fetch_assoc($product);

$original_price = (float)$row['price'];

$size_prices = [];

if (!empty($row['size_prices'])) {
    $decoded = json_decode($row['size_prices'], true);

    if (is_array($decoded)) {
        $size_prices = $decoded;
    }
}

if (empty($size_prices)) {
    $size_prices = [
        'S' => $original_price,
        'M' => $original_price,
        'L' => $original_price,
        'XL' => $original_price + 100,
        'XXL' => $original_price + 200
    ];
}

if ($size == '' || !isset($size_prices[$size])) {
    $size = 'M';

    if (!isset($size_prices[$size])) {
        $size = array_key_first($size_prices);
    }
}

$price = (float)$size_prices[$size];

$size_safe = mysqli_real_escape_string($conn, $size);

$check = mysqli_query(
    $conn,
    "SELECT id
     FROM cart
     WHERE user_id='$user_id'
     AND product_id='$product_id'
     AND size='$size_safe'
     LIMIT 1"
);

if ($check && mysqli_num_rows($check) > 0) {

    mysqli_query(
        $conn,
        "UPDATE cart
         SET quantity = quantity + 1,
             price='$price'
         WHERE user_id='$user_id'
         AND product_id='$product_id'
         AND size='$size_safe'"
    );

} else {

    mysqli_query(
        $conn,
        "INSERT INTO cart
        (user_id, product_id, quantity, size, price)
        VALUES
        ('$user_id', '$product_id', 1, '$size_safe', '$price')"
    );
}

$back = isset($_SERVER['HTTP_REFERER']) ? $_SERVER['HTTP_REFERER'] : 'index.php';

header("Location: " . $back . "?cart_added=1");
exit();
?>
```
