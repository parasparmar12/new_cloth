<?php

session_start();
include("db.php");

header("Content-Type: application/json");

/* CHECK LOGIN */
if (!isset($_SESSION['user_id'])) {
    echo json_encode([
        "status" => "login"
    ]);
    exit();
}

/* CHECK PRODUCT ID */
if (!isset($_POST['product_id'])) {
    echo json_encode([
        "status" => "error",
        "message" => "Product ID missing"
    ]);
    exit();
}

$user_id = $_SESSION['user_id'];
$product_id = intval($_POST['product_id']);

/* CHECK PRODUCT EXISTS */
$product = mysqli_query(
    $conn,
    "SELECT * FROM products WHERE id='$product_id'"
);

if (mysqli_num_rows($product) == 0) {

    echo json_encode([
        "status" => "error",
        "message" => "Product not found"
    ]);

    exit();
}

/* CHECK ALREADY IN WISHLIST */
$check = mysqli_query(
    $conn,
    "SELECT * FROM wishlist
     WHERE user_id='$user_id'
     AND product_id='$product_id'"
);

if (mysqli_num_rows($check) > 0) {

    echo json_encode([
        "status" => "exists"
    ]);

    exit();
}

/* ADD TO WISHLIST */
$insert = mysqli_query(
    $conn,
    "INSERT INTO wishlist (user_id, product_id)
     VALUES ('$user_id', '$product_id')"
);

if ($insert) {

    echo json_encode([
        "status" => "success"
    ]);

} else {

    echo json_encode([
        "status" => "error",
        "message" => "Database error"
    ]);
}

?>