<?php
session_start();
include("../db.php");

if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit();
}


/* ================= ADD COUPON ================= */

if (isset($_POST['add_coupon'])) {

    $coupon_code = strtoupper(trim($_POST['coupon_code']));
    $discount_type = trim($_POST['discount_type']);
    $discount_value = floatval($_POST['discount_value']);
    $min_order_amount = floatval($_POST['min_order_amount']);

    /* Visible date fields */
    $start_display = trim($_POST['start_display']);
    $end_display = trim($_POST['end_display']);

    $status = trim($_POST['status']);


    /* ================= DATE CONVERSION ================= */

    function convertDateToDatabase($date)
    {
        // Required format: DD-MM-YYYY

        $parts = explode("-", $date);

        if (count($parts) != 3) {
            return false;
        }

        $day = intval($parts[0]);
        $month = intval($parts[1]);
        $year = intval($parts[2]);

        if (!checkdate($month, $day, $year)) {
            return false;
        }

        return sprintf(
            "%04d-%02d-%02d",
            $year,
            $month,
            $day
        );
    }


    $start_date = convertDateToDatabase($start_display);
    $end_date = convertDateToDatabase($end_display);


    /* Invalid Start Date */

    if ($start_date === false) {

        echo "<script>
                alert('Invalid Start Date! Please use DD-MM-YYYY format. Example: 06-09-2026');
                history.back();
              </script>";

        exit();
    }


    /* Invalid End Date */

    if ($end_date === false) {

        echo "<script>
                alert('Invalid End Date! Please use DD-MM-YYYY format. Example: 30-09-2026');
                history.back();
              </script>";

        exit();
    }


    /* ================= DATE OBJECTS ================= */

    $today = new DateTime(
        date("Y-m-d"),
        new DateTimeZone("Asia/Kolkata")
    );

    $start = new DateTime($start_date);
    $end = new DateTime($end_date);


    /* Start date cannot be past */

    if ($start < $today) {

        echo "<script>
                alert('Start Date cannot be in the past.');
                history.back();
              </script>";

        exit();
    }


    /* End date cannot be before Start Date */

    if ($end < $start) {

        echo "<script>
                alert('End Date cannot be before Start Date.');
                history.back();
              </script>";

        exit();
    }


    /* ================= VALIDATION ================= */

    if ($coupon_code == "") {

        echo "<script>
                alert('Please enter Coupon Code.');
                history.back();
              </script>";

        exit();
    }


    if ($discount_value <= 0) {

        echo "<script>
                alert('Discount value must be greater than 0.');
                history.back();
              </script>";

        exit();
    }


    if (
        $discount_type == "percentage" &&
        $discount_value > 100
    ) {

        echo "<script>
                alert('Percentage discount cannot be more than 100%.');
                history.back();
              </script>";

        exit();
    }


    if ($min_order_amount < 0) {

        echo "<script>
                alert('Minimum order amount cannot be negative.');
                history.back();
              </script>";

        exit();
    }


    /* ================= ESCAPE VALUES ================= */

    $coupon_code_db = mysqli_real_escape_string(
        $conn,
        $coupon_code
    );

    $discount_type_db = mysqli_real_escape_string(
        $conn,
        $discount_type
    );

    $status_db = mysqli_real_escape_string(
        $conn,
        $status
    );


    /* ================= DUPLICATE CHECK ================= */

    $duplicate = mysqli_query(
        $conn,
        "SELECT coupon_id
         FROM coupons
         WHERE UPPER(TRIM(coupon_code)) = '$coupon_code_db'
         LIMIT 1"
    );


    if (mysqli_num_rows($duplicate) > 0) {

        echo "<script>
                alert('This Coupon Code already exists.');
                history.back();
              </script>";

        exit();
    }


    /* ================= INSERT ================= */

    $sql = "INSERT INTO coupons
            (
                coupon_code,
                discount_type,
                discount_value,
                min_order_amount,
                start_date,
                end_date,
                status
            )
            VALUES
            (
                '$coupon_code_db',
                '$discount_type_db',
                '$discount_value',
                '$min_order_amount',
                '$start_date',
                '$end_date',
                '$status_db'
            )";


    if (mysqli_query($conn, $sql)) {

        echo "<script>
                alert('Coupon Added Successfully!');
                window.location='add_coupon.php';
              </script>";

        exit();

    } else {

        echo "Database Error: " . mysqli_error($conn);
    }
}


/* ================= DELETE COUPON ================= */

if (isset($_GET['delete_coupon'])) {

    $coupon_id = intval($_GET['delete_coupon']);

    $delete = mysqli_query(
        $conn,
        "DELETE FROM coupons
         WHERE coupon_id='$coupon_id'"
    );

    if ($delete) {

        echo "<script>
                alert('Coupon Removed Successfully!');
                window.location='add_coupon.php';
              </script>";

        exit();

    } else {

        echo "Error: " . mysqli_error($conn);
    }
}


/* ================= TODAY ================= */

$today_display = date("d-m-Y");

?>

<!DOCTYPE html>
<html>

<head>

<title>Coupons - Wear Zone</title>

<style>

* {
    box-sizing: border-box;
    margin: 0;
    padding: 0;
}


/* ================= SIDEBAR ================= */

.sidebar {
    width: 250px;
    height: 100vh;
    background: #111;
    position: fixed;
    left: 0;
    top: 0;
    padding-top: 20px;
}

.sidebar h2 {
    color: white;
    text-align: center;
    margin-bottom: 30px;
}

.sidebar a {
    display: block;
    color: white;
    text-decoration: none;
    padding: 15px 25px;
    transition: .3s;
}

.sidebar a:hover {
    background: red;
}


/* ================= BODY ================= */

body {
    font-family: Arial, sans-serif;
    background: #f4f4f4;
    min-height: 100vh;
    margin: 0;
    padding: 30px;
}


/* ================= MAIN ================= */

.main {
    margin-left: 250px;
    padding: 0 20px;
}


/* ================= ADD COUPON BOX ================= */

.coupon-box {
    width: 450px;
    max-width: 100%;
    margin: 0 auto 40px auto;
    background: white;
    padding: 30px;
    border-radius: 10px;
    box-shadow: 0 0 15px #ccc;
}

h2 {
    text-align: center;
    margin-bottom: 25px;
}

label {
    font-weight: bold;
}

input,
select {
    width: 100%;
    padding: 10px;
    margin-top: 8px;
    margin-bottom: 18px;
    box-sizing: border-box;
}

.date-input {
    font-size: 16px;
    letter-spacing: 1px;
}

.date-help {
    display: block;
    margin-top: -12px;
    margin-bottom: 18px;
    font-size: 12px;
    color: #666;
}

button {
    width: 100%;
    padding: 12px;
    background: #111;
    color: white;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    font-size: 16px;
}

button:hover {
    background: red;
}


/* ================= COUPON LIST ================= */

.coupon-list {
    width: 100%;
    margin: 0 auto;
    background: white;
    padding: 20px;
    border-radius: 10px;
    box-shadow: 0 0 15px #ccc;
    overflow-x: auto;
}

.coupon-list h2 {
    text-align: center;
}

table {
    width: 100%;
    border-collapse: collapse;
    min-width: 850px;
}

th {
    background: #111;
    color: white;
    padding: 12px;
}

td {
    padding: 12px;
    text-align: center;
    border-bottom: 1px solid #ddd;
}

.delete-btn {
    background: red;
    color: white;
    padding: 8px 15px;
    text-decoration: none;
    border-radius: 5px;
}

.delete-btn:hover {
    background: darkred;
}


/* ================= MOBILE ================= */

@media (max-width: 800px) {

    .sidebar {
        width: 200px;
    }

    .main {
        margin-left: 200px;
        padding: 0 10px;
    }

}

@media (max-width: 600px) {

    .sidebar {
        position: relative;
        width: 100%;
        height: auto;
    }

    .main {
        margin-left: 0;
        padding: 20px 10px;
    }

    body {
        padding: 0;
    }

    .coupon-box {
        margin-top: 20px;
    }

}

</style>

</head>

<body>


<!-- ================= SIDEBAR ================= -->

<div class="sidebar">

    <h2>WEAR ZONE</h2>

    <a href="dashboard.php">🏠 Dashboard</a>
    <a href="category.php">📂 Manage Category</a>
    <a href="add_product.php">➕ Add Product</a>
    <a href="add_offer.php">🎁 Manage Offers</a>
    <a href="add_coupon.php">🎟️ Manage Coupons</a>
    <a href="view_products.php">📦 View Products</a>
    <a href="view_orders.php">🛒 View Orders</a>
    <a href="../logout.php">🚪 Logout</a>

</div>


<!-- ================= MAIN ================= -->

<div class="main">


<!-- ================= ADD COUPON ================= -->

<div class="coupon-box">

<h2>🎟️ Add New Coupon</h2>

<form method="POST" id="couponForm">


<label>Coupon Code</label>

<input
    type="text"
    name="coupon_code"
    placeholder="Example: WELCOME10"
    maxlength="50"
    required
>


<label>Discount Type</label>

<select name="discount_type" required>

<option value="">
-- Select Discount Type --
</option>

<option value="percentage">
Percentage (%)
</option>

<option value="fixed">
Fixed Amount (₹)
</option>

</select>


<label>Discount Value</label>

<input
    type="number"
    name="discount_value"
    min="0.01"
    step="0.01"
    placeholder="Example: 10"
    required
>


<label>Minimum Order Amount</label>

<input
    type="number"
    name="min_order_amount"
    min="0"
    step="0.01"
    value="0"
    placeholder="Example: 500"
    required
>


<!-- ================= START DATE ================= -->

<label>Start Date</label>

<input
    type="text"
    name="start_display"
    id="start_display"
    class="date-input"
    placeholder="DD-MM-YYYY"
    maxlength="10"
    inputmode="numeric"
    required
>

<span class="date-help">
📅 Format: DD-MM-YYYY &nbsp; Example: 06-09-2026
</span>


<!-- ================= END DATE ================= -->

<label>End Date</label>

<input
    type="text"
    name="end_display"
    id="end_display"
    class="date-input"
    placeholder="DD-MM-YYYY"
    maxlength="10"
    inputmode="numeric"
    required
>

<span class="date-help">
📅 Format: DD-MM-YYYY &nbsp; Example: 30-09-2026
</span>


<label>Status</label>

<select name="status" required>

<option value="Active">
Active
</option>

<option value="Inactive">
Inactive
</option>

</select>


<button type="submit" name="add_coupon">
Add Coupon
</button>

</form>

</div>


<!-- ================= CURRENT COUPONS ================= -->

<div class="coupon-list">

<h2>📋 Current Coupons</h2>

<table>

<tr>

<th>Coupon Code</th>
<th>Discount Type</th>
<th>Discount</th>
<th>Min Order</th>
<th>Start Date</th>
<th>End Date</th>
<th>Status</th>
<th>Action</th>

</tr>


<?php

$coupon_query = mysqli_query(
    $conn,
    "SELECT *
     FROM coupons
     ORDER BY coupon_id DESC"
);


if (mysqli_num_rows($coupon_query) > 0) {

while ($coupon = mysqli_fetch_assoc($coupon_query)) {

?>

<tr>

<td>

<?php

echo htmlspecialchars(
    $coupon['coupon_code']
);

?>

</td>


<td>

<?php

echo htmlspecialchars(
    $coupon['discount_type']
);

?>

</td>


<td>

<?php

if ($coupon['discount_type'] == "percentage") {

    echo htmlspecialchars(
        $coupon['discount_value']
    ) . "%";

} else {

    echo "₹" .
        htmlspecialchars(
            $coupon['discount_value']
        );
}

?>

</td>


<td>

₹<?php

echo number_format(
    $coupon['min_order_amount'],
    2
);

?>

</td>


<td>

<?php

$date = strtotime($coupon['start_date']);

if ($date !== false) {

    echo date("d-m-Y", $date);

} else {

    echo htmlspecialchars(
        $coupon['start_date']
    );
}

?>

</td>


<td>

<?php

$date = strtotime($coupon['end_date']);

if ($date !== false) {

    echo date("d-m-Y", $date);

} else {

    echo htmlspecialchars(
        $coupon['end_date']
    );
}

?>

</td>


<td>

<?php

echo htmlspecialchars(
    $coupon['status']
);

?>

</td>


<td>

<a
    href="add_coupon.php?delete_coupon=<?php echo $coupon['coupon_id']; ?>"
    class="delete-btn"
    onclick="return confirm('Are you sure you want to remove this coupon?');"
>
    Remove
</a>

</td>

</tr>

<?php

}

} else {

?>

<tr>

<td colspan="8">
No Coupons Available
</td>

</tr>

<?php

}

?>

</table>

</div>

</div>


<script>

/* ================= DATE INPUT ================= */

function formatDateInput(input)
{
    input.addEventListener("input", function()
    {

        let value = this.value.replace(/\D/g, "");

        if (value.length > 8)
        {
            value = value.substring(0, 8);
        }

        if (value.length >= 5)
        {
            value =
                value.substring(0, 2) +
                "-" +
                value.substring(2, 4) +
                "-" +
                value.substring(4);
        }
        else if (value.length >= 3)
        {
            value =
                value.substring(0, 2) +
                "-" +
                value.substring(2);
        }

        this.value = value;

    });
}


formatDateInput(
    document.getElementById("start_display")
);

formatDateInput(
    document.getElementById("end_display")
);


/* ================= FORM VALIDATION ================= */

document.getElementById("couponForm")
.addEventListener("submit", function(e)
{

    const start =
        document.getElementById("start_display").value;

    const end =
        document.getElementById("end_display").value;


    const datePattern =
        /^\d{2}-\d{2}-\d{4}$/;


    if (!datePattern.test(start))
    {
        alert(
            "Start Date must be DD-MM-YYYY.\nExample: 06-09-2026"
        );

        e.preventDefault();
        return;
    }


    if (!datePattern.test(end))
    {
        alert(
            "End Date must be DD-MM-YYYY.\nExample: 30-09-2026"
        );

        e.preventDefault();
        return;
    }

});

</script>


</body>

</html>