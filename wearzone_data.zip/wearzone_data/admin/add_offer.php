<?php
session_start();
include("../db.php");

if(!isset($_SESSION['admin']))
{
    header("Location: login.php");
    exit();
}


/* ================= ADD OFFER ================= */

if(isset($_POST['add_offer']))
{
    $offer_name = $_POST['offer_name'];
    $product_id = $_POST['product_id'];
    $discount = $_POST['discount'];
    $start_date = $_POST['start_date'];
    $end_date = $_POST['end_date'];

    $sql = "INSERT INTO offers
            (offer_name, product_id, discount, start_date, end_date)
            VALUES
            ('$offer_name', '$product_id', '$discount', '$start_date', '$end_date')";

    if(mysqli_query($conn, $sql))
    {
        echo "<script>
                alert('Offer Added Successfully');
                window.location='add_offer.php';
              </script>";
        exit();
    }
    else
    {
        echo "Error: " . mysqli_error($conn);
    }
}


/* ================= DELETE OFFER ================= */

if(isset($_GET['delete_offer']))
{
    $offer_id = intval($_GET['delete_offer']);

    $delete = mysqli_query(
        $conn,
        "DELETE FROM offers WHERE offer_id='$offer_id'"
    );

    if($delete)
    {
        echo "<script>
                alert('Offer Removed Successfully');
                window.location='add_offer.php';
              </script>";
        exit();
    }
    else
    {
        echo "Error: " . mysqli_error($conn);
    }
}

?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Offers - Wear Zone</title>

<style>

* {
    box-sizing: border-box;
    margin: 0;
    padding: 0;
}


/* ================= SIDEBAR ================= */

.sidebar {
    width: 250px;
    height: 100vh;
    background: #111;
    position: fixed;
    left: 0;
    top: 0;
    padding-top: 20px;
}

.sidebar h2 {
    color: white;
    text-align: center;
    margin-bottom: 30px;
}

.sidebar a {
    display: block;
    color: white;
    text-decoration: none;
    padding: 15px 25px;
    transition: .3s;
}

.sidebar a:hover {
    background: red;
}


/* ================= BODY ================= */

body {
    font-family: Arial, sans-serif;
    background: #f4f4f4;
    min-height: 100vh;
    margin: 0;
    padding: 30px;
}


/* ================= MAIN ================= */

.main {
    margin-left: 250px;
    padding: 0 20px;
}


/* ================= ADD OFFER BOX ================= */

.offer-box {
    width: 100%;
    max-width: 500px;
    margin: 0 auto 40px auto;
    background: white;
    padding: 30px;
    border-radius: 10px;
    box-shadow: 0 0 15px #ccc;
}

.offer-box h2 {
    text-align: center;
    margin-bottom: 25px;
}

label {
    font-weight: bold;
}

input,
select {
    width: 100%;
    padding: 10px;
    margin-top: 8px;
    margin-bottom: 18px;
    box-sizing: border-box;
}

button {
    width: 100%;
    padding: 12px;
    background: #111;
    color: white;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    font-size: 16px;
}

button:hover {
    background: red;
}


/* ================= OFFER LIST ================= */

.offer-list {
    width: 100%;
    background: white;
    padding: 20px;
    border-radius: 10px;
    box-shadow: 0 0 15px #ccc;
    overflow-x: auto;
}

.offer-list h2 {
    text-align: center;
    margin-bottom: 20px;
}

table {
    width: 100%;
    border-collapse: collapse;
    min-width: 750px;
}

th {
    background: #111;
    color: white;
    padding: 12px;
}

td {
    padding: 12px;
    text-align: center;
    border-bottom: 1px solid #ddd;
}

.delete-btn {
    background: red;
    color: white;
    padding: 8px 15px;
    text-decoration: none;
    border-radius: 5px;
}

.delete-btn:hover {
    background: darkred;
}


/* ================= MOBILE ================= */

@media (max-width: 800px) {

    .sidebar {
        width: 200px;
    }

    .main {
        margin-left: 200px;
        padding: 0 10px;
    }

}

@media (max-width: 600px) {

    .sidebar {
        position: relative;
        width: 100%;
        height: auto;
    }

    .main {
        margin-left: 0;
        padding: 20px 10px;
    }

    body {
        padding: 0;
    }

    .offer-box {
        margin-top: 20px;
    }

}

</style>

</head>

<body>


<!-- ================= SIDEBAR ================= -->

<div class="sidebar">

    <h2>WEAR ZONE</h2>

    <a href="dashboard.php">🏠 Dashboard</a>
    <a href="category.php">📂 Manage Category</a>
    <a href="add_product.php">➕ Add Product</a>
    <a href="add_offer.php">🎁 Manage Offers</a>
    <a href="add_coupon.php">🎟️ Manage Coupons</a>
    <a href="view_products.php">📦 View Products</a>
    <a href="view_orders.php">🛒 View Orders</a>
    <a href="../logout.php">🚪 Logout</a>

</div>


<!-- ================= MAIN ================= -->

<div class="main">


    <!-- ================= ADD OFFER ================= -->

    <div class="offer-box">

        <h2>🎁 Add New Offer</h2>

        <form method="POST">

            <label>Offer Name</label>

            <input
                type="text"
                name="offer_name"
                placeholder="Example: Summer Sale"
                required
            >


            <label>Select Product</label>

            <select name="product_id" required>

                <option value="">-- Select Product --</option>

                <?php

                $product_query = mysqli_query(
                    $conn,
                    "SELECT id, product_name
                     FROM products
                     ORDER BY product_name ASC"
                );

                while($product = mysqli_fetch_assoc($product_query))
                {
                ?>

                    <option value="<?php echo $product['id']; ?>">

                        <?php
                        echo htmlspecialchars($product['product_name']);
                        ?>

                    </option>

                <?php
                }
                ?>

            </select>


            <label>Discount (%)</label>

            <input
                type="number"
                name="discount"
                min="1"
                max="100"
                placeholder="Example: 20"
                required
            >


            <label>Start Date</label>

            <input
                type="date"
                name="start_date"
                required
            >


            <label>End Date</label>

            <input
                type="date"
                name="end_date"
                required
            >


            <button type="submit" name="add_offer">
                Add Offer
            </button>

        </form>

    </div>


    <!-- ================= OFFER LIST ================= -->

    <div class="offer-list">

        <h2>📋 Current Offers</h2>

        <table>

            <tr>
                <th>Offer Name</th>
                <th>Product</th>
                <th>Discount</th>
                <th>Start Date</th>
                <th>End Date</th>
                <th>Action</th>
            </tr>


            <?php

            $offer_query = mysqli_query(
                $conn,
                "SELECT offers.*,
                        products.product_name
                 FROM offers
                 INNER JOIN products
                 ON offers.product_id = products.id
                 ORDER BY offers.offer_id DESC"
            );


            if(mysqli_num_rows($offer_query) > 0)
            {

                while($offer = mysqli_fetch_assoc($offer_query))
                {

            ?>

            <tr>

                <td>
                    <?php
                    echo htmlspecialchars($offer['offer_name']);
                    ?>
                </td>


                <td>
                    <?php
                    echo htmlspecialchars($offer['product_name']);
                    ?>
                </td>


                <td>
                    <?php
                    echo htmlspecialchars($offer['discount']);
                    ?>%
                </td>


                <td>
                    <?php
                    echo htmlspecialchars($offer['start_date']);
                    ?>
                </td>


                <td>
                    <?php
                    echo htmlspecialchars($offer['end_date']);
                    ?>
                </td>


                <td>

                    <a
                        href="add_offer.php?delete_offer=<?php echo $offer['offer_id']; ?>"
                        class="delete-btn"
                        onclick="return confirm('Are you sure you want to remove this offer?');"
                    >
                        Remove
                    </a>

                </td>

            </tr>

            <?php

                }

            }
            else
            {

            ?>

            <tr>

                <td colspan="6">
                    No Offers Available
                </td>

            </tr>

            <?php

            }

            ?>

        </table>

    </div>

</div>


</body>

</html>