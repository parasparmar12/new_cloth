<?php
include("../db.php");

if (isset($_POST['add_product'])) {

    $product_name = $_POST['product_name'];
    $category = $_POST['category'];
    $price = $_POST['price'];
    $stock = $_POST['stock'];
    $description = $_POST['description'];

    $image = $_FILES['image']['name'];
    $tmp_image = $_FILES['image']['tmp_name'];

    move_uploaded_file($tmp_image, "../uploads/" . $image);

    $sql = "INSERT INTO products
            (product_name, category, price, stock, description, image)
            VALUES
            ('$product_name', '$category', '$price', '$stock', '$description', '$image')";

    if (mysqli_query($conn, $sql)) {
        echo "<script>
                alert('Product Added Successfully');
                window.location.href='view_products.php';
              </script>";
    } else {
        echo "<script>alert('Error while adding product');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Add Product - WEAR ZONE</title>

<style>

* {
    box-sizing: border-box;
    margin: 0;
    padding: 0;
}

/* ================= SIDEBAR ================= */

.sidebar {
    width: 250px;
    height: 100vh;
    background: #111;
    position: fixed;
    left: 0;
    top: 0;
    padding-top: 20px;
}

.sidebar h2 {
    color: white;
    text-align: center;
    margin-bottom: 30px;
}

.sidebar a {
    display: block;
    color: white;
    text-decoration: none;
    padding: 15px 25px;
    transition: .3s;
}

.sidebar a:hover {
    background: red;
}

/* ================= BODY ================= */

body {
    font-family: Arial, sans-serif;
    background: #f5f5f5;
    min-height: 100vh;
    margin: 0;
    padding: 30px;
}

/* ================= MAIN ================= */

.main {
    margin-left: 250px;
    padding: 0 20px;
    display: flex;
    justify-content: center;
}

/* ================= PRODUCT CONTAINER ================= */

.product-container {
    width: 100%;
    max-width: 650px;
    background: #fff;
    padding: 35px 40px;
    border-radius: 12px;
    box-shadow: 0 8px 30px rgba(0,0,0,0.10);
}

.product-header {
    text-align: center;
    margin-bottom: 30px;
}

.product-header h2 {
    font-size: 30px;
    color: #111;
    margin-bottom: 8px;
}

.product-header p {
    color: #777;
    font-size: 14px;
}

.form-group {
    margin-bottom: 20px;
}

.form-group label {
    display: block;
    font-size: 14px;
    font-weight: 600;
    color: #222;
    margin-bottom: 8px;
}

.form-group input,
.form-group textarea,
.form-group select {
    width: 100%;
    padding: 12px 14px;
    border: 1px solid #ddd;
    border-radius: 7px;
    outline: none;
    font-size: 14px;
    transition: 0.3s;
}

.form-group input:focus,
.form-group textarea:focus,
.form-group select:focus {
    border-color: #111;
    box-shadow: 0 0 0 2px rgba(0,0,0,0.05);
}

.form-group textarea {
    height: 110px;
    resize: vertical;
}

.form-row {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 18px;
}

.file-box {
    border: 2px dashed #ddd;
    border-radius: 8px;
    padding: 20px;
    text-align: center;
    background: #fafafa;
}

.file-box input {
    border: none;
    padding: 5px;
}

.add-btn {
    width: 100%;
    padding: 14px;
    background: #111;
    color: #fff;
    border: none;
    border-radius: 7px;
    font-size: 15px;
    font-weight: 600;
    cursor: pointer;
    transition: 0.3s;
    margin-top: 8px;
}

.add-btn:hover {
    background: #333;
    transform: translateY(-1px);
}

.back-btn {
    display: block;
    text-align: center;
    margin-top: 18px;
    color: #555;
    text-decoration: none;
    font-size: 14px;
}

.back-btn:hover {
    color: #111;
}

/* ================= MOBILE ================= */

@media (max-width: 800px) {

    .sidebar {
        width: 200px;
    }

    .main {
        margin-left: 200px;
        padding: 0 10px;
    }

    .product-container {
        padding: 25px 20px;
    }
}

@media (max-width: 600px) {

    .sidebar {
        position: relative;
        width: 100%;
        height: auto;
    }

    .main {
        margin-left: 0;
        padding: 20px 10px;
    }

    body {
        padding: 0;
    }

    .product-container {
        padding: 25px 20px;
    }

    .product-header h2 {
        font-size: 25px;
    }

    .form-row {
        grid-template-columns: 1fr;
        gap: 0;
    }
}

</style>

</head>

<body>

<!-- ================= SIDEBAR ================= -->

<div class="sidebar">

    <h2>WEAR ZONE</h2>

    <a href="dashboard.php">🏠 Dashboard</a>
    <a href="category.php">📂 Manage Category</a>
    <a href="add_product.php">➕ Add Product</a>
    <a href="add_offer.php">🎁 Manage Offers</a>
    <a href="add_coupon.php">🎟️ Manage Coupons</a>
    <a href="view_products.php">📦 View Products</a>
    <a href="view_orders.php">🛒 View Orders</a>
    <a href="../logout.php">🚪 Logout</a>

</div>

<!-- ================= MAIN ================= -->

<div class="main">

    <div class="product-container">

        <div class="product-header">

            <h2>Add Product</h2>

            <p>Add a new product to your WEAR ZONE store</p>

        </div>

        <form method="POST" enctype="multipart/form-data">

            <div class="form-group">

                <label>Product Name</label>

                <input
                    type="text"
                    name="product_name"
                    placeholder="Enter product name"
                    required
                >

            </div>

            <div class="form-group">

                <label>Category</label>

                <select name="category" required>

                    <option value="">Select Category</option>
                    <option value="Shirt">Shirt</option>
                    <option value="T-Shirt">T-Shirt</option>
                    <option value="Kurata">Kurata</option>
                    <option value="Trousers">Trousers</option>
                    <option value="Jackets">Jackets</option>

                </select>

            </div>

            <div class="form-row">

                <div class="form-group">

                    <label>Price</label>

                    <input
                        type="number"
                        name="price"
                        placeholder="Enter price"
                        min="0"
                        required
                    >

                </div>

                <div class="form-group">

                    <label>Stock</label>

                    <input
                        type="number"
                        name="stock"
                        placeholder="Enter stock"
                        min="0"
                        required
                    >

                </div>

            </div>

            <div class="form-group">

                <label>Description</label>

                <textarea
                    name="description"
                    placeholder="Enter product description"
                ></textarea>

            </div>

            <div class="form-group">

                <label>Product Image</label>

                <div class="file-box">

                    <input
                        type="file"
                        name="image"
                        accept="image/*"
                        required
                    >

                </div>

            </div>

            <button
                type="submit"
                name="add_product"
                class="add-btn"
            >
                Add Product
            </button>

        </form>

        <a href="view_products.php" class="back-btn">
            ← Back to Products
        </a>

    </div>

</div>

</body>

</html>