<?php

session_start();
include("db.php");


/* ================= CHECK LOGIN ================= */

if(!isset($_SESSION['user_id']))
{
    header("Location: login.php");
    exit();
}


$user_id = $_SESSION['user_id'];


/* ================= CHECK COUPON CODE ================= */

if(!isset($_POST['coupon_code']) || empty(trim($_POST['coupon_code'])))
{
    $_SESSION['coupon_error'] = "Please enter coupon code.";
    header("Location: cart.php");
    exit();
}


$coupon_code = strtoupper(
    trim(
        mysqli_real_escape_string(
            $conn,
            $_POST['coupon_code']
        )
    )
);


/* ================= CALCULATE CART TOTAL ================= */

$cart_query = mysqli_query(
    $conn,
    "SELECT cart.quantity, products.price
     FROM cart
     INNER JOIN products
     ON cart.product_id = products.id
     WHERE cart.user_id='$user_id'"
);


$grand_total = 0;


while($row = mysqli_fetch_assoc($cart_query))
{
    $grand_total += $row['price'] * $row['quantity'];
}


/* ================= CHECK EMPTY CART ================= */

if($grand_total <= 0)
{
    $_SESSION['coupon_error'] = "Your cart is empty.";
    header("Location: cart.php");
    exit();
}


/* ================= FIND COUPON ================= */

$coupon_query = mysqli_query(
    $conn,
    "SELECT *
     FROM coupons
     WHERE UPPER(coupon_code)='$coupon_code'
     LIMIT 1"
);


if(mysqli_num_rows($coupon_query) == 0)
{
    $_SESSION['coupon_error'] = "Invalid coupon code.";
    header("Location: cart.php");
    exit();
}


$coupon = mysqli_fetch_assoc($coupon_query);


/* ================= CHECK STATUS ================= */

if($coupon['status'] != 'Active')
{
    $_SESSION['coupon_error'] = "This coupon is inactive.";
    header("Location: cart.php");
    exit();
}


/* ================= CHECK DATE ================= */

$today = date('Y-m-d');


if($today < $coupon['start_date'] || $today > $coupon['end_date'])
{
    $_SESSION['coupon_error'] = "This coupon has expired or is not active yet.";
    header("Location: cart.php");
    exit();
}


/* ================= CHECK MINIMUM ORDER ================= */

if($grand_total < $coupon['min_order_amount'])
{
    $_SESSION['coupon_error'] =
        "Minimum order amount is ₹" .
        number_format($coupon['min_order_amount'], 2);

    header("Location: cart.php");
    exit();
}


/* ================= CALCULATE DISCOUNT ================= */

if($coupon['discount_type'] == 'percentage')
{
    $discount =
        ($grand_total * $coupon['discount_value']) / 100;
}
else
{
    $discount = $coupon['discount_value'];
}


/* Discount cannot be greater than cart total */

if($discount > $grand_total)
{
    $discount = $grand_total;
}


$final_total = $grand_total - $discount;


/* ================= SAVE COUPON IN SESSION ================= */

$_SESSION['coupon_id'] = $coupon['coupon_id'];

$_SESSION['coupon_code'] = $coupon['coupon_code'];

$_SESSION['coupon_discount'] = $discount;

$_SESSION['coupon_final_total'] = $final_total;


/* ================= SUCCESS ================= */

$_SESSION['coupon_success'] =
    "Coupon applied successfully! You saved ₹" .
    number_format($discount, 2);


header("Location: cart.php");
exit();

?>