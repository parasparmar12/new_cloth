<?php
session_start();

if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit();
}

include("../db.php");


/* ================= ADD CATEGORY ================= */

if (isset($_POST['add_category'])) {

    $category_name = mysqli_real_escape_string(
        $conn,
        $_POST['category_name']
    );

    if (!empty($category_name)) {

        $check = mysqli_query(
            $conn,
            "SELECT * FROM categories
             WHERE category_name='$category_name'"
        );

        if (mysqli_num_rows($check) > 0) {

            echo "<script>
                    alert('Category already exists');
                  </script>";

        } else {

            $sql = "INSERT INTO categories (category_name)
                    VALUES ('$category_name')";

            if (mysqli_query($conn, $sql)) {

                echo "<script>
                        alert('Category Added Successfully');
                        window.location='category.php';
                      </script>";

            } else {

                echo "<script>
                        alert('Error adding category');
                      </script>";
            }
        }
    }
}


/* ================= DELETE CATEGORY ================= */

if (isset($_GET['delete'])) {

    $id = intval($_GET['delete']);

    mysqli_query(
        $conn,
        "DELETE FROM categories WHERE id=$id"
    );

    echo "<script>
            alert('Category Deleted Successfully');
            window.location='category.php';
          </script>";
}


/* ================= GET ALL CATEGORIES ================= */

$result = mysqli_query(
    $conn,
    "SELECT * FROM categories ORDER BY id DESC"
);

?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Manage Category - WEAR ZONE</title>


    <style>

        /* ================= BODY ================= */

        * {
            box-sizing: border-box;
        }

        body {
            font-family: Arial, sans-serif;
            background: #f4f4f4;
            margin: 0;
            padding: 0;
        }


        /* ================= SIDEBAR ================= */

        .sidebar {
            width: 250px;
            height: 100vh;
            background: #111;
            position: fixed;
            left: 0;
            top: 0;
            padding: 20px 10px;
            overflow-y: auto;
        }


        .sidebar h2 {
            color: white;
            text-align: center;
            margin: 5px 0 30px 0;
            font-size: 24px;
        }


       .sidebar a {
    display: block;
    color: white;
    text-decoration: none;
    padding: 15px 25px;
    transition: .3s;
}

.sidebar a:hover {
    background: red;
}

        /* ================= MAIN ================= */

        .main {
            margin-left: 250px;
            padding: 35px;
            min-height: 100vh;
        }


        /* ================= CONTAINER ================= */

        .container {
            max-width: 950px;
            margin: auto;
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.15);
        }


        /* ================= HEADING ================= */

        .container h2 {
            text-align: center;
            margin-top: 0;
            margin-bottom: 30px;
            color: #222;
        }


        /* ================= FORM ================= */

        form {
            display: flex;
            gap: 10px;
            margin-bottom: 30px;
        }


        input[type="text"] {
            flex: 1;
            padding: 12px;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 15px;
            outline: none;
        }


        input[type="text"]:focus {
            border-color: green;
        }


        /* ================= ALL GREEN BUTTON ================= */

        button {
            padding: 12px 20px;
            background: green;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 15px;
            transition: 0.3s;
        }


        button:hover {
            background: #006400;
        }


        /* ================= TABLE ================= */

        table {
            width: 100%;
            border-collapse: collapse;
        }


        th,
        td {
            padding: 13px;
            border: 1px solid #ddd;
            text-align: center;
        }


        th {
            background: #111;
            color: white;
        }


        tr:hover {
            background: #f9f9f9;
        }


        /* ================= EDIT & DELETE ================= */

        .edit,
        .delete {
            display: inline-block;
            color: white;
            background: green;
            padding: 7px 12px;
            text-decoration: none;
            border-radius: 5px;
            margin: 2px;
            transition: 0.3s;
        }


        .edit:hover,
        .delete:hover {
            background: #006400;
        }


        /* ================= MOBILE ================= */

        @media (max-width: 768px) {

            .sidebar {
                width: 200px;
            }

            .main {
                margin-left: 200px;
                padding: 20px;
            }

            form {
                flex-direction: column;
            }

            .container {
                padding: 20px;
            }

            table {
                font-size: 13px;
            }

            .edit,
            .delete {
                display: block;
                margin: 4px 0;
            }
        }

    </style>

</head>


<body>


<!-- ================= SIDEBAR ================= -->

<div class="sidebar">

    <h2>WEAR ZONE</h2>


    <a href="dashboard.php">
        🏠 Dashboard
    </a>


    <a href="category.php">
        📂 Manage Category
    </a>


    <a href="add_product.php">
        ➕ Add Product
    </a>


    <a href="add_offer.php">
        🎁 Manage Offers
    </a>


    <a href="add_coupon.php">
        🎟️ Manage Coupons
    </a>


    <a href="view_products.php">
        📦 View Products
    </a>


    <a href="view_orders.php">
        🛒 View Orders
    </a>


    <a href="../logout.php">
        🚪 Logout
    </a>

</div>


<!-- ================= MAIN CONTENT ================= -->

<div class="main">

    <div class="container">

        <h2>📂 Manage Category</h2>


        <!-- ================= ADD CATEGORY ================= -->

        <form method="POST">

            <input
                type="text"
                name="category_name"
                placeholder="Enter Category Name"
                required
            >

            <button
                type="submit"
                name="add_category"
            >
                ➕ Add Category
            </button>

        </form>


        <!-- ================= CATEGORY TABLE ================= -->

        <table>

            <tr>

                <th>ID</th>

                <th>Category Name</th>

                <th>Action</th>

            </tr>


            <?php while ($row = mysqli_fetch_assoc($result)) { ?>

            <tr>

                <td>
                    <?php echo $row['id']; ?>
                </td>


                <td>
                    <?php
                    echo htmlspecialchars(
                        $row['category_name']
                    );
                    ?>
                </td>


                <td>

                    <a
                        class="edit"
                        href="edit_category.php?id=<?php echo $row['id']; ?>"
                    >
                        ✏️ Edit
                    </a>


                    <a
                        class="delete"
                        href="category.php?delete=<?php echo $row['id']; ?>"
                        onclick="return confirm('Are you sure you want to delete this category?')"
                    >
                        🗑 Delete
                    </a>

                </td>

            </tr>

            <?php } ?>

        </table>

    </div>

</div>


</body>

</html>