<?php
session_start();

if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit();
}

include("../db.php");


/* ================= TOTAL PRODUCTS ================= */

$product = mysqli_query($conn, "SELECT * FROM products");
$total_products = mysqli_num_rows($product);


/* ================= TOTAL USERS ================= */

$user = mysqli_query($conn, "SELECT * FROM users");
$total_users = mysqli_num_rows($user);


/* ================= TOTAL ORDERS ================= */

$order = mysqli_query($conn, "SELECT * FROM orders");
$total_orders = mysqli_num_rows($order);


/* ================= TOTAL COUPONS ================= */

$coupon = mysqli_query($conn, "SELECT * FROM coupons");
$total_coupons = mysqli_num_rows($coupon);

?>

<!DOCTYPE html>
<html>

<head>

<meta charset="UTF-8">

<title>Admin Dashboard</title>

<link
href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
rel="stylesheet"
>


<style>

/* ================= BODY ================= */

body {
    background: #f4f4f4;
    margin: 0;
    font-family: Arial, sans-serif;
}


/* ================= SIDEBAR ================= */

.sidebar {
    width: 250px;
    height: 100vh;
    background: #111;
    position: fixed;
    left: 0;
    top: 0;
    padding-top: 20px;
}


.sidebar h2 {
    color: white;
    text-align: center;
    margin-bottom: 30px;
}


.sidebar a {
    display: block;
    color: white;
    text-decoration: none;
    padding: 15px 25px;
    transition: .3s;
}


.sidebar a:hover {
    background: red;
}


/* ================= MAIN ================= */

.main {
    margin-left: 260px;
    padding: 30px;
}


/* ================= DASHBOARD CARDS ================= */

.dashboard-card {
    border: none;
    border-radius: 15px;
    box-shadow: 0 5px 15px rgba(0,0,0,.15);
    color: white;
    min-height: 150px;
}


.products-card {
    background: #2563EB;
}


.users-card {
    background: #16A34A;
}


.orders-card {
    background: #F97316;
}


.coupons-card {
    background: #7C3AED;
}


.dashboard-card h5 {
    font-size: 20px;
    font-weight: 600;
}


.dashboard-card h1 {
    font-size: 50px;
    margin-top: 15px;
}


/* ================= QUICK BUTTONS ================= */

.quick-btn {
    display: block;
    width: 100%;
    padding: 15px;
    color: white;
    text-decoration: none;
    text-align: center;
    border-radius: 8px;
    font-size: 16px;
    transition: .3s;
}


.quick-btn:hover {
    color: white;
    transform: translateY(-2px);
}


/* ================= QUICK BUTTON COLORS ================= */

.category-btn {
    background: #2563EB;
}


.category-btn:hover {
    background: #1D4ED8;
}


.product-btn {
    background: #16A34A;
}


.product-btn:hover {
    background: #15803D;
}


.offer-btn {
    background: #F97316;
}


.offer-btn:hover {
    background: #EA580C;
}


.coupon-btn {
    background: #7C3AED;
}


.coupon-btn:hover {
    background: #6D28D9;
}


.view-product-btn {
    background: #2563EB;
}


.view-product-btn:hover {
    background: #1D4ED8;
}


.order-btn {
    background: #F97316;
}


.order-btn:hover {
    background: #EA580C;
}


/* ================= MOBILE ================= */

@media (max-width: 768px) {

    .sidebar {
        width: 210px;
    }

    .main {
        margin-left: 210px;
        padding: 20px;
    }

}

</style>

</head>


<body>


<!-- ================================================= -->
<!-- SIDEBAR -->
<!-- ================================================= -->

<div class="sidebar">

    <h2>WEAR ZONE</h2>


    <a href="dashboard.php">
        🏠 Dashboard
    </a>


    <a href="category.php">
        📂 Manage Category
    </a>


    <a href="add_product.php">
        ➕ Add Product
    </a>


    <a href="add_offer.php">
        🎁 Manage Offers
    </a>


    <a href="add_coupon.php">
        🎟️ Manage Coupons
    </a>


    <a href="view_products.php">
        📦 View Products
    </a>


    <a href="view_orders.php">
        🛒 View Orders
    </a>


    <a href="../logout.php">
        🚪 Logout
    </a>

</div>


<!-- ================================================= -->
<!-- MAIN CONTENT -->
<!-- ================================================= -->

<div class="main">


    <h2 class="mb-4">
        Admin Dashboard
    </h2>


    <!-- ================================================= -->
    <!-- DASHBOARD CARDS -->
    <!-- ================================================= -->

    <div class="row g-4">


        <!-- TOTAL PRODUCTS -->

        <div class="col-md-3">

            <div class="dashboard-card products-card">

                <div class="card-body">

                    <h5>
                        Total Products
                    </h5>

                    <h1>
                        <?php echo $total_products; ?>
                    </h1>

                </div>

            </div>

        </div>


        <!-- TOTAL USERS -->

        <div class="col-md-3">

            <div class="dashboard-card users-card">

                <div class="card-body">

                    <h5>
                        Total Users
                    </h5>

                    <h1>
                        <?php echo $total_users; ?>
                    </h1>

                </div>

            </div>

        </div>


        <!-- TOTAL ORDERS -->

        <div class="col-md-3">

            <div class="dashboard-card orders-card">

                <div class="card-body">

                    <h5>
                        Total Orders
                    </h5>

                    <h1>
                        <?php echo $total_orders; ?>
                    </h1>

                </div>

            </div>

        </div>


        <!-- TOTAL COUPONS -->

        <div class="col-md-3">

            <div class="dashboard-card coupons-card">

                <div class="card-body">

                    <h5>
                        Total Coupons
                    </h5>

                    <h1>
                        <?php echo $total_coupons; ?>
                    </h1>

                </div>

            </div>

        </div>

    </div>


    <br><br>


    <!-- ================================================= -->
    <!-- QUICK ACTION BUTTONS -->
    <!-- ================================================= -->

    <div class="row g-3">


        <!-- MANAGE CATEGORY -->

        <div class="col-md-4">

            <a
                href="category.php"
                class="quick-btn category-btn"
            >
                📂 Manage Category
            </a>

        </div>


        <!-- ADD PRODUCT -->

        <div class="col-md-4">

            <a
                href="add_product.php"
                class="quick-btn product-btn"
            >
                ➕ Add Product
            </a>

        </div>


        <!-- MANAGE OFFERS -->

        <div class="col-md-4">

            <a
                href="add_offer.php"
                class="quick-btn offer-btn"
            >
                🎁 Manage Offers
            </a>

        </div>


        <!-- MANAGE COUPONS -->

        <div class="col-md-4">

            <a
                href="add_coupon.php"
                class="quick-btn coupon-btn"
            >
                🎟️ Manage Coupons
            </a>

        </div>


        <!-- VIEW PRODUCTS -->

        <div class="col-md-4">

            <a
                href="view_products.php"
                class="quick-btn view-product-btn"
            >
                📦 View Products
            </a>

        </div>


        <!-- VIEW ORDERS -->

        <div class="col-md-4">

            <a
                href="view_orders.php"
                class="quick-btn order-btn"
            >
                🛒 View Orders
            </a>

        </div>


    </div>


</div>


</body>

</html>