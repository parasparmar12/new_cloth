<?php

session_start();

include("../db.php");


/* CHECK ADMIN LOGIN */

if (!isset($_SESSION['admin'])) {

    header("Location: login.php");
    exit();

}


/* CHECK ORDER ID */

if (!isset($_GET['id']) || empty($_GET['id'])) {

    header("Location: view_orders.php");
    exit();

}


$id = intval($_GET['id']);


/* DELETE ORDER ITEMS FIRST */

mysqli_query(
    $conn,
    "DELETE FROM order_items WHERE order_id='$id'"
);


/* DELETE ORDER */

$delete = mysqli_query(
    $conn,
    "DELETE FROM orders WHERE id='$id'"
);


/* CHECK DELETE */

if ($delete) {

    header("Location: view_orders.php");
    exit();

} else {

    echo "Error deleting order: " . mysqli_error($conn);

}

?>