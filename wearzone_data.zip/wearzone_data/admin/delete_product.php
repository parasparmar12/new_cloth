<?php
include("../db.php");

$id = $_GET['id'];

$result = mysqli_query($conn, "SELECT image FROM products WHERE id='$id'");
$row = mysqli_fetch_assoc($result);

if(file_exists("../uploads/".$row['image']))
{
    unlink("../uploads/".$row['image']);
}

mysqli_query($conn, "DELETE FROM products WHERE id='$id'");

header("Location:view_products.php");
exit();
?>