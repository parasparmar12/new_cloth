```php
<?php
session_start();

if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit();
}

include("../db.php");

/* CHECK ID */
if (!isset($_GET['id'])) {
    header("Location: category.php");
    exit();
}

$id = intval($_GET['id']);


/* GET CATEGORY */
$query = mysqli_query(
    $conn,
    "SELECT * FROM categories WHERE id=$id"
);

if (mysqli_num_rows($query) == 0) {
    echo "Category not found";
    exit();
}

$row = mysqli_fetch_assoc($query);


/* UPDATE CATEGORY */
if (isset($_POST['update_category'])) {

    $category_name = mysqli_real_escape_string(
        $conn,
        $_POST['category_name']
    );

    if (empty($category_name)) {

        $error = "Category name cannot be empty.";

    } else {

        /* CHECK DUPLICATE CATEGORY */

        $check = mysqli_query(
            $conn,
            "SELECT * FROM categories
             WHERE category_name='$category_name'
             AND id!=$id"
        );

        if (mysqli_num_rows($check) > 0) {

            $error = "This category already exists.";

        } else {

            $update = mysqli_query(
                $conn,
                "UPDATE categories
                 SET category_name='$category_name'
                 WHERE id=$id"
            );

            if ($update) {

                echo "<script>
                        alert('Category Updated Successfully');
                        window.location='category.php';
                      </script>";

                exit();

            } else {

                $error = "Category update failed.";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html>

<head>

    <meta charset="UTF-8">

    <title>Edit Category</title>

    <style>

        body{
            background:#f4f4f4;
            font-family:Arial;
            padding:40px;
        }

        .container{
            max-width:500px;
            margin:auto;
            background:white;
            padding:30px;
            border-radius:12px;
            box-shadow:0 5px 15px rgba(0,0,0,.15);
        }

        h2{
            text-align:center;
            margin-bottom:25px;
        }

        input{
            width:100%;
            padding:12px;
            margin-bottom:15px;
            border:1px solid #ccc;
            border-radius:6px;
            box-sizing:border-box;
        }

        button{
            width:100%;
            padding:12px;
            background:blue;
            color:white;
            border:none;
            border-radius:6px;
            cursor:pointer;
            font-size:16px;
        }

        button:hover{
            background:#0000aa;
        }

        .back{
            display:block;
            text-align:center;
            margin-top:15px;
            text-decoration:none;
            color:#333;
        }

        .error{
            background:#ffd6d6;
            color:red;
            padding:10px;
            border-radius:5px;
            margin-bottom:15px;
            text-align:center;
        }

    </style>

</head>

<body>

<div class="container">

    <h2>✏️ Edit Category</h2>

    <?php if (isset($error)) { ?>

        <div class="error">
            <?php echo $error; ?>
        </div>

    <?php } ?>


    <form method="POST">

        <input
            type="text"
            name="category_name"
            value="<?php echo htmlspecialchars($row['category_name']); ?>"
            placeholder="Enter Category Name"
            required
        >

        <button type="submit" name="update_category">
            💾 Update Category
        </button>

    </form>


    <a href="category.php" class="back">
        ← Back to Manage Category
    </a>

</div>

</body>

</html>
```
