<?php
include("../db.php");

$id = $_GET['id'];

$result = mysqli_query($conn, "SELECT * FROM products WHERE id='$id'");
$row = mysqli_fetch_assoc($result);

if(isset($_POST['update_product'])){

    $product_name = $_POST['product_name'];
    $category = $_POST['category'];
    $price = $_POST['price'];
    $stock = $_POST['stock'];
    $description = $_POST['description'];

    $image = $_FILES['image']['name'];

    if($image != ""){

        $tmp_image = $_FILES['image']['tmp_name'];

        move_uploaded_file($tmp_image,"../uploads/".$image);

    }else{

        $image = $row['image'];

    }

    mysqli_query($conn,"UPDATE products SET
        product_name='$product_name',
        category='$category',
        price='$price',
        stock='$stock',
        description='$description',
        image='$image'
        WHERE id='$id'
    ");

    header("Location:view_products.php");
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Product</title>

    <style>

        body{
            font-family:Arial;
            background:#f5f5f5;
        }

        .box{
            width:500px;
            margin:40px auto;
            background:white;
            padding:20px;
            border-radius:10px;
            box-shadow:0 0 10px rgba(0,0,0,.2);
        }

        input,textarea{
            width:100%;
            padding:10px;
            margin:10px 0;
        }

        button{
            background:red;
            color:white;
            border:none;
            padding:10px 20px;
            cursor:pointer;
        }

        img{
            width:120px;
            margin:10px 0;
        }

    </style>

</head>

<body>

<div class="box">

<h2>Edit Product</h2>

<form method="POST" enctype="multipart/form-data">

<input type="text" name="product_name"
value="<?php echo $row['product_name']; ?>" required>

<input type="text" name="category"
value="<?php echo $row['category']; ?>" required>

<input type="number" name="price"
value="<?php echo $row['price']; ?>" required>

<input type="number" name="stock"
value="<?php echo $row['stock']; ?>" required>

<textarea name="description"><?php echo $row['description']; ?></textarea>

<img src="../uploads/<?php echo $row['image']; ?>">

<br><br>

<input type="file" name="image">

<br><br>

<button type="submit" name="update_product">
Update Product
</button>

</form>

</div>

</body>
</html>