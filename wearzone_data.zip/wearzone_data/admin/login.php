<?php
session_start();

$error = "";

if(isset($_POST['login']))
{
    $username = $_POST['username'];
    $password = $_POST['password'];

    if($username == "Rutik" && $password == "94845")
    {
        $_SESSION['admin'] = true;
        $_SESSION['admin_username'] = "Rutik";

        header("Location: dashboard.php");
        exit();
    }
    else
    {
        $error = "Invalid Username or Password";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Admin Login</title>

<style>

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family:Arial,sans-serif;
}

body{
    background:#f4f4f4;
    display:flex;
    justify-content:center;
    align-items:center;
    height:100vh;
}

.login-box{
    width:350px;
    background:#fff;
    padding:30px;
    border-radius:10px;
    box-shadow:0 0 15px rgba(0,0,0,.2);
}

h2{
    text-align:center;
    margin-bottom:20px;
}

input{
    width:100%;
    padding:12px;
    margin:10px 0;
}

button{
    width:100%;
    padding:12px;
    background:#111;
    color:#fff;
    border:none;
    cursor:pointer;
    font-size:16px;
}

button:hover{
    background:red;
}

.error{
    color:red;
    text-align:center;
    margin-bottom:10px;
}

</style>

</head>

<body>

<div class="login-box">

<h2>Admin Login</h2>

<?php
if($error!="")
{
    echo "<div class='error'>$error</div>";
}
?>

<form method="POST">

<input type="text" name="username" placeholder="Username" required>

<input type="password" name="password" placeholder="Password" required>

<button type="submit" name="login">
Login
</button>

</form>

</div>

</body>
</html>