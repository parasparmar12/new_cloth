<?php

session_start();

include("../db.php");


/* CHECK ADMIN LOGIN */

if (!isset($_SESSION['admin'])) {

    header("Location: login.php");
    exit();

}


/* CHECK ORDER ID */

if (!isset($_GET['id']) || empty($_GET['id'])) {

    header("Location: view_orders.php");
    exit();

}


$order_id = intval($_GET['id']);


/* GET ORDER */

$result = mysqli_query(
    $conn,
    "SELECT * FROM orders WHERE id='$order_id'"
);


if (mysqli_num_rows($result) == 0) {

    echo "Order not found!";
    exit();

}


$row = mysqli_fetch_assoc($result);


/* UPDATE ORDER */

if (isset($_POST['update'])) {

    $status = mysqli_real_escape_string(
        $conn,
        $_POST['status']
    );


    $update = mysqli_query(
        $conn,
        "UPDATE orders
         SET status='$status'
         WHERE id='$order_id'"
    );


    if ($update) {

        header("Location: view_orders.php");
        exit();

    } else {

        echo "Error: " . mysqli_error($conn);

    }

}

?>

<!DOCTYPE html>

<html>

<head>

    <meta charset="UTF-8">

    <title>Update Order - WEAR ZONE</title>


    <style>

        body {

            margin: 0;

            font-family: Arial, sans-serif;

            background: #f5f5f5;

        }


        .box {

            width: 450px;

            margin: 70px auto;

            background: white;

            padding: 30px;

            border-radius: 12px;

            box-shadow: 0 5px 20px rgba(0,0,0,.15);

        }


        h2 {

            text-align: center;

            margin-bottom: 25px;

        }


        .info {

            background: #f5f5f5;

            padding: 15px;

            border-radius: 8px;

            margin-bottom: 20px;

        }


        .info p {

            margin: 8px 0;

        }


        label {

            font-weight: bold;

        }


        select {

            width: 100%;

            padding: 12px;

            margin-top: 8px;

            border: 1px solid #ccc;

            border-radius: 6px;

            font-size: 16px;

        }


        button {

            width: 100%;

            padding: 12px;

            margin-top: 20px;

            background: green;

            color: white;

            border: none;

            border-radius: 6px;

            font-size: 17px;

            cursor: pointer;

        }


        button:hover {

            background: darkgreen;

        }


        .back {

            display: block;

            text-align: center;

            margin-top: 15px;

            padding: 12px;

            background: #111;

            color: white;

            text-decoration: none;

            border-radius: 6px;

        }


        .back:hover {

            background: #333;

        }

    </style>

</head>


<body>


<div class="box">


    <h2>📦 Update Order</h2>


    <div class="info">

        <p>
            <b>Order ID:</b>
            #WZ<?= htmlspecialchars($row['id']); ?>
        </p>


        <p>
            <b>Customer:</b>
            <?= htmlspecialchars($row['customer_name']); ?>
        </p>


        <p>
            <b>Mobile:</b>
            <?= htmlspecialchars($row['mobile']); ?>
        </p>


        <p>
            <b>Total:</b>
            ₹<?= htmlspecialchars($row['total']); ?>
        </p>


        <p>
            <b>Payment:</b>
            <?= htmlspecialchars($row['payment_method']); ?>
        </p>

    </div>


    <form method="POST">


        <label>
            Order Status
        </label>


        <select name="status" required>


            <option
                value="Pending"
                <?php
                if ($row['status'] == "Pending") {
                    echo "selected";
                }
                ?>>

                🟠 Pending

            </option>


            <option
                value="Shipped"
                <?php
                if ($row['status'] == "Shipped") {
                    echo "selected";
                }
                ?>>

                🔵 Shipped

            </option>


            <option
                value="Delivered"
                <?php
                if ($row['status'] == "Delivered") {
                    echo "selected";
                }
                ?>>

                🟢 Delivered

            </option>


        </select>


        <button
            type="submit"
            name="update">

            ✅ Update Order

        </button>


    </form>


    <a
        href="view_orders.php"
        class="back">

        ⬅ Back to Orders

    </a>


</div>


</body>

</html>