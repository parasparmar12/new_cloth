<?php
session_start();
include("../db.php");

$sql = mysqli_query($conn, "SELECT * FROM orders ORDER BY id DESC");
?>

<!DOCTYPE html>
<html>
<head>

<title>All Orders</title>

<style>

*{
    box-sizing:border-box;
}

body{
    font-family:Arial;
    background:#f5f5f5;
    margin:0;
    padding:30px;
}

/* ================= SIDEBAR ================= */

.sidebar{
    width:250px;
    height:100vh;
    background:#111;
    position:fixed;
    left:0;
    top:0;
    padding-top:20px;
}

.sidebar h2{
    color:white;
    text-align:center;
    margin-bottom:30px;
}

.sidebar a{
    display:block;
    color:white;
    text-decoration:none;
    padding:15px 25px;
    transition:.3s;
}

.sidebar a:hover{
    background:red;
}

/* ================= MAIN ================= */

.main{
    margin-left:250px;
    padding:0 20px;
}

.container{
    width:100%;
    margin:auto;
}

h2{
    text-align:center;
    margin-bottom:25px;
}

table{
    width:100%;
    border-collapse:collapse;
    background:#fff;
    box-shadow:0 5px 15px rgba(0,0,0,.1);
}

th,td{
    padding:12px;
    border:1px solid #ddd;
    text-align:center;
}

th{
    background:#111;
    color:#fff;
}

.btn{
    padding:8px 12px;
    color:#fff;
    text-decoration:none;
    border-radius:5px;
    display:inline-block;
    margin:2px;
}

.edit{
    background:green;
}

.delete{
    background:red;
}

.edit:hover{
    background:darkgreen;
}

.delete:hover{
    background:darkred;
}

/* ================= MOBILE ================= */

@media(max-width:768px){

    .sidebar{
        width:200px;
    }

    .main{
        margin-left:200px;
        padding:0 10px;
    }

    table{
        min-width:1000px;
    }

}

</style>

</head>

<body>

<!-- ================= SIDEBAR ================= -->

<div class="sidebar">

    <h2>WEAR ZONE</h2>

    <a href="dashboard.php">🏠 Dashboard</a>

    <a href="category.php">📂 Manage Category</a>

    <a href="add_product.php">➕ Add Product</a>

    <a href="add_offer.php">🎁 Manage Offers</a>

    <a href="add_coupon.php">🎟️ Manage Coupons</a>

    <a href="view_products.php">📦 View Products</a>

    <a href="view_orders.php">🛒 View Orders</a>

    <a href="../logout.php">🚪 Logout</a>

</div>


<!-- ================= MAIN CONTENT ================= -->

<div class="main">

<div class="container">

<h2>📦 Customer Orders</h2>

<table>

<tr>

<th>ID</th>

<th>Customer</th>

<th>Mobile</th>

<th>Address</th>

<th>Total</th>

<th>Payment</th>

<th>Date</th>

<th>Status</th>

<th>Action</th>

</tr>


<?php

if(mysqli_num_rows($sql) > 0)
{

    while($row = mysqli_fetch_assoc($sql))
    {

?>

<tr>

<td>
    #WZ<?= $row['id']; ?>
</td>

<td>
    <?= htmlspecialchars($row['customer_name']); ?>
</td>

<td>
    <?= htmlspecialchars($row['mobile']); ?>
</td>

<td>
    <?= htmlspecialchars($row['address']); ?>
</td>

<td>
    ₹<?= number_format($row['total'],2); ?>
</td>

<td>
    💳 <?= htmlspecialchars($row['payment_method']); ?>
</td>

<td>
    <?= htmlspecialchars($row['order_date']); ?>
</td>

<td>

<?php

if($row['status'] == "Pending")
{
    echo "<span style='color:orange;font-weight:bold;'>🟠 Pending</span>";
}
elseif($row['status'] == "Shipped")
{
    echo "<span style='color:blue;font-weight:bold;'>🔵 Shipped</span>";
}
elseif($row['status'] == "Delivered")
{
    echo "<span style='color:green;font-weight:bold;'>🟢 Delivered</span>";
}
else
{
    echo htmlspecialchars($row['status']);
}

?>

</td>

<td>

<a
    class="btn edit"
    href="update_order.php?id=<?= $row['id']; ?>">

    Update

</a>

<a
    class="btn delete"
    href="delete_order.php?id=<?= $row['id']; ?>"
    onclick="return confirm('Delete this order?');">

    Delete

</a>

</td>

</tr>

<?php

    }

}
else
{

?>

<tr>

<td colspan="9">

    No Orders Found

</td>

</tr>

<?php

}

?>

</table>

</div>

</div>

</body>

</html>