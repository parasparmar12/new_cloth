<?php

include("../db.php");

$result = mysqli_query($conn, "SELECT * FROM products ORDER BY id DESC");

?>

<!DOCTYPE html>
<html>

<head>

    <title>View Products</title>

    <style>

        * {
            box-sizing: border-box;
        }

        body {
            font-family: Arial, sans-serif;
            background: #f4f4f4;
            margin: 0;
            padding: 30px;
        }

        /* ================= SIDEBAR ================= */

        .sidebar {
            width: 250px;
            height: 100vh;
            background: #111;
            position: fixed;
            left: 0;
            top: 0;
            padding-top: 20px;
        }

        .sidebar h2 {
            color: white;
            text-align: center;
            margin-bottom: 30px;
        }

        .sidebar a {
            display: block;
            color: white;
            text-decoration: none;
            padding: 15px 25px;
            transition: 0.3s;
        }

        .sidebar a:hover {
            background: red;
        }

        /* ================= MAIN ================= */

        .main {
            margin-left: 250px;
            padding: 0 20px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            background: white;
        }

        th, td {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: center;
        }

        img {
            width: 80px;
            height: 80px;
            object-fit: cover;
        }

        th {
            background: red;
            color: white;
        }

        /* ================= MOBILE ================= */

        @media (max-width: 768px) {

            .sidebar {
                width: 200px;
            }

            .main {
                margin-left: 200px;
                padding: 0 10px;
            }

            table {
                min-width: 850px;
            }

        }

    </style>

</head>

<body>

<!-- ================= SIDEBAR ================= -->

<div class="sidebar">

    <h2>WEAR ZONE</h2>

    <a href="dashboard.php">🏠 Dashboard</a>

    <a href="category.php">📂 Manage Category</a>

    <a href="add_product.php">➕ Add Product</a>

    <a href="add_offer.php">🎁 Manage Offers</a>

    <a href="add_coupon.php">🎟️ Manage Coupons</a>

    <a href="view_products.php">📦 View Products</a>

    <a href="view_orders.php">🛒 View Orders</a>

    <a href="../logout.php">🚪 Logout</a>

</div>


<!-- ================= MAIN CONTENT ================= -->

<div class="main">

    <h2 align="center">All Products</h2>

    <table>

        <tr>

            <th>ID</th>

            <th>Image</th>

            <th>Name</th>

            <th>Category</th>

            <th>Price</th>

            <th>Stock</th>

            <th>Edit</th>

            <th>Delete</th>

        </tr>

        <?php while($row = mysqli_fetch_assoc($result)){ ?>

        <tr>

            <td>
                <?php echo $row['id']; ?>
            </td>

            <td>

                <img src="../uploads/<?php echo $row['image']; ?>">

            </td>

            <td>
                <?php echo $row['product_name']; ?>
            </td>

            <td>
                <?php echo $row['category']; ?>
            </td>

            <td>
                ₹<?php echo $row['price']; ?>
            </td>

            <td>
                <?php echo $row['stock']; ?>
            </td>

            <td>

                <a href="edit_product.php?id=<?php echo $row['id']; ?>">
                    ✏️ Edit
                </a>

            </td>

            <td>

                <a href="delete_product.php?id=<?php echo $row['id']; ?>"
                   onclick="return confirm('Are you sure?')">

                    🗑 Delete

                </a>

            </td>

        </tr>

        <?php } ?>

    </table>

</div>

</body>

</html>