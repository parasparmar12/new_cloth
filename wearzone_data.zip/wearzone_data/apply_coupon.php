<?php

session_start();
include("db.php");

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

if (!isset($_POST['coupon_code']) || empty(trim($_POST['coupon_code']))) {
    $_SESSION['coupon_error'] = "Please enter coupon code.";
    header("Location: view_cart.php");
    exit();
}

$coupon_code = trim($_POST['coupon_code']);
$coupon_code = mysqli_real_escape_string($conn, $coupon_code);

$coupon_query = mysqli_query(
    $conn,
    "SELECT *
     FROM coupons
     WHERE UPPER(TRIM(coupon_code)) = UPPER('$coupon_code')
     LIMIT 1"
);

if (!$coupon_query) {
    $_SESSION['coupon_error'] =
        "Coupon database error: " . mysqli_error($conn);

    header("Location: view_cart.php");
    exit();
}

if (mysqli_num_rows($coupon_query) == 0) {
    $_SESSION['coupon_error'] = "Invalid coupon code.";

    unset($_SESSION['coupon_discount']);
    unset($_SESSION['coupon_code']);

    header("Location: view_cart.php");
    exit();
}

$coupon = mysqli_fetch_assoc($coupon_query);

if (strtolower(trim($coupon['status'])) != 'active') {
    $_SESSION['coupon_error'] = "This coupon is inactive.";

    unset($_SESSION['coupon_discount']);
    unset($_SESSION['coupon_code']);

    header("Location: view_cart.php");
    exit();
}

$today = date('Y-m-d');

if ($today < $coupon['start_date']) {
    $_SESSION['coupon_error'] = "This coupon is not active yet.";

    unset($_SESSION['coupon_discount']);
    unset($_SESSION['coupon_code']);

    header("Location: view_cart.php");
    exit();
}

if ($today > $coupon['end_date']) {
    $_SESSION['coupon_error'] = "This coupon has expired.";

    unset($_SESSION['coupon_discount']);
    unset($_SESSION['coupon_code']);

    header("Location: view_cart.php");
    exit();
}

$cart_query = mysqli_query(
    $conn,
    "SELECT quantity, price
     FROM cart
     WHERE user_id='$user_id'"
);

if (!$cart_query) {
    $_SESSION['coupon_error'] =
        "Cart database error: " . mysqli_error($conn);

    header("Location: view_cart.php");
    exit();
}

$grand_total = 0;

while ($row = mysqli_fetch_assoc($cart_query)) {
    $grand_total +=
        (float)$row['price'] * (int)$row['quantity'];
}

if ($grand_total <= 0) {
    $_SESSION['coupon_error'] = "Your cart is empty.";

    header("Location: view_cart.php");
    exit();
}

if ($grand_total < $coupon['min_order_amount']) {
    $_SESSION['coupon_error'] =
        "Minimum order amount is ₹" .
        number_format($coupon['min_order_amount'], 2);

    unset($_SESSION['coupon_discount']);
    unset($_SESSION['coupon_code']);

    header("Location: view_cart.php");
    exit();
}

if (strtolower($coupon['discount_type']) == 'percentage') {
    $discount =
        ($grand_total * $coupon['discount_value']) / 100;
} else {
    $discount = $coupon['discount_value'];
}

if ($discount > $grand_total) {
    $discount = $grand_total;
}

$final_total = $grand_total - $discount;

$_SESSION['coupon_id'] = $coupon['coupon_id'];
$_SESSION['coupon_code'] = $coupon['coupon_code'];
$_SESSION['coupon_discount'] = $discount;
$_SESSION['coupon_final_total'] = $final_total;

$_SESSION['coupon_success'] =
    "Coupon applied successfully! You saved ₹" .
    number_format($discount, 2);

header("Location: view_cart.php");
exit();

?>
