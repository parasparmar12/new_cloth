<?php

session_start();
include("db.php");

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

if (!isset($_GET['id'])) {
    header("Location: my_orders.php");
    exit();
}

$order_id = intval($_GET['id']);

/*
   Only user's own Pending order can be cancelled
*/

$sql = mysqli_query(
    $conn,
    "UPDATE orders
     SET status='Cancelled'
     WHERE id='$order_id'
     AND user_id='$user_id'
     AND status='Pending'"
);

header("Location: my_orders.php");
exit();

?>