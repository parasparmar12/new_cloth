<?php
session_start();
include("db.php");

$coupon_error = $_SESSION['coupon_error'] ?? '';
$coupon_success = $_SESSION['coupon_success'] ?? '';

unset($_SESSION['coupon_error']);
unset($_SESSION['coupon_success']);

$coupon_discount = $_SESSION['coupon_discount'] ?? 0;
$coupon_code = $_SESSION['coupon_code'] ?? '';

if(!isset($_SESSION['username'])){
    header("Location: login.php");
    exit();
}

$username = $_SESSION['username'];

$user = mysqli_query($conn,"SELECT * FROM users WHERE username='$username'");
$userData = mysqli_fetch_assoc($user);

$user_id = $userData['id'];

$product_id = $_GET['id'];
echo "User ID = ".$user_id."<br>";
echo "Product ID = ".$product_id;
exit();

$check = mysqli_query($conn,"SELECT * FROM cart WHERE user_id='$user_id' AND product_id='$product_id'");

if(mysqli_num_rows($check) > 0){

    mysqli_query($conn,"UPDATE cart SET quantity = quantity + 1 WHERE user_id='$user_id' AND product_id='$product_id'");

}else{

    mysqli_query($conn,"INSERT INTO cart(user_id,product_id,quantity)
    VALUES('$user_id','$product_id','1')");

}

header("Location:index.php");
exit();
?>