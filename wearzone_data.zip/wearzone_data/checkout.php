<?php
session_start();
include("db.php");


/* CHECK LOGIN */

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}


$user_id = $_SESSION['user_id'];


/* GET CART */

$sql = mysqli_query($conn, "
    SELECT cart.*, products.price, products.product_name
    FROM cart
    INNER JOIN products
    ON cart.product_id = products.id
    WHERE cart.user_id = '$user_id'
");


$grand_total = 0;
$cart_items = 0;

while ($row = mysqli_fetch_assoc($sql)) {
    $grand_total += $row['price'] * $row['quantity'];
    $cart_items += $row['quantity'];
}

/* ================= APPLY COUPON DISCOUNT ================= */

$coupon_code = $_SESSION['coupon_code'] ?? '';
$coupon_discount = floatval($_SESSION['coupon_discount'] ?? 0);

/* Never allow discount to exceed current cart total */
if ($coupon_discount > $grand_total) {
    $coupon_discount = $grand_total;
}

$final_total = $grand_total - $coupon_discount;


/* CHECK EMPTY CART */

if ($cart_items == 0) {

    echo "<script>
            alert('Your cart is empty!');
            window.location='view_cart.php';
          </script>";

    exit();
}

?>


<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Checkout - WEAR ZONE</title>


    <style>

        * {
            box-sizing: border-box;
        }


        body {
            font-family: Arial, sans-serif;
            background: #f5f5f5;
            margin: 0;
            padding: 30px;
        }


        .box {
            width: 550px;
            max-width: 95%;
            margin: 30px auto;
            background: white;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 5px 20px rgba(0,0,0,.15);
        }


        h2 {
            text-align: center;
            margin-bottom: 25px;
        }


        label {
            display: block;
            font-weight: bold;
            margin-top: 15px;
            margin-bottom: 5px;
        }


        input,
        textarea,
        select {

            width: 100%;

            padding: 12px;

            margin-bottom: 10px;

            border: 1px solid #ccc;

            border-radius: 6px;

            font-size: 15px;
        }


        textarea {
            height: 100px;
            resize: vertical;
        }


        .total-box {

            background: #f4f4f4;

            padding: 15px;

            border-radius: 8px;

            margin: 20px 0;

            text-align: center;
        }


        .total-box h3 {

            margin: 0;

            color: #e60000;

            font-size: 24px;
        }


        .payment-box {

            border: 1px solid #ddd;

            padding: 15px;

            border-radius: 8px;

            margin-top: 10px;
        }


        .payment-option {

            display: flex;

            align-items: center;

            gap: 10px;

            padding: 10px;

            border-bottom: 1px solid #eee;
        }


        .payment-option:last-child {
            border-bottom: none;
        }


        .payment-option input {

            width: auto;

            margin: 0;
        }


        .payment-option label {

            margin: 0;

            font-weight: normal;

            cursor: pointer;
        }


        button {

            width: 100%;

            padding: 14px;

            background: #111;

            color: white;

            border: none;

            border-radius: 6px;

            font-size: 18px;

            cursor: pointer;

            margin-top: 20px;
        }


        button:hover {
            background: green;
        }


        .back {

            display: block;

            text-align: center;

            margin-top: 15px;

            color: #111;

            text-decoration: none;
        }


    </style>

</head>


<body>


<div class="box">


    <h2>🛒 Checkout</h2>


    <form action="place_order.php" method="POST">


        <!-- CUSTOMER NAME -->

        <label>
            Customer Name
        </label>

        <input
            type="text"
            name="customer_name"
            placeholder="Enter Customer Name"
            required>


        <!-- MOBILE -->

        <label>
            Mobile Number
        </label>

        <input
            type="tel"
            name="mobile"
            placeholder="Enter Mobile Number"
            required>


        <!-- ADDRESS -->

        <label>
            Delivery Address
        </label>

        <textarea
            name="address"
            placeholder="Enter complete delivery address"
            required></textarea>


        <!-- TOTAL -->

        <div class="total-box">

            <p style="margin:0 0 8px; font-size:16px;">
                Original Total : ₹<?= number_format($grand_total, 2); ?>
            </p>

            <?php if ($coupon_discount > 0) { ?>

                <p style="margin:0 0 8px; color:green; font-size:16px;">
                    Coupon <?= htmlspecialchars($coupon_code); ?> : -₹<?= number_format($coupon_discount, 2); ?>
                </p>

            <?php } ?>

            <h3>
                Final Total : ₹<?= number_format($final_total, 2); ?>
            </h3>

        </div>


        <!-- PAYMENT METHOD -->

        <label>
            💳 Select Payment Method
        </label>


        <div class="payment-box">


            <!-- COD -->

            <div class="payment-option">

                <input
                    type="radio"
                    name="payment_method"
                    id="cod"
                    value="Cash on Delivery"
                    checked
                    required>

                <label for="cod">
                    💵 Cash on Delivery
                </label>

            </div>


            <!-- UPI -->

            <div class="payment-option">

                <input
                    type="radio"
                    name="payment_method"
                    id="upi"
                    value="UPI"
                    required>

                <label for="upi">
                    📱 UPI
                </label>

            </div>


            <!-- CARD -->

            <div class="payment-option">

                <input
                    type="radio"
                    name="payment_method"
                    id="card"
                    value="Card"
                    required>

                <label for="card">
                    💳 Credit / Debit Card
                </label>

            </div>


        </div>


        <!-- PLACE ORDER -->

        <button type="submit">
            Place Order
        </button>


    </form>


    <a
        href="view_cart.php"
        class="back">

        ← Back to Cart

    </a>


</div>


</body>

</html>