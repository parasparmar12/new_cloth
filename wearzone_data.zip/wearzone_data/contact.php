<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Contact Us | WearZone</title>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">

<style>

*{
margin:0;
padding:0;
box-sizing:border-box;
font-family:'Poppins',sans-serif;
}

body{
height:100vh;
display:flex;
justify-content:center;
align-items:center;
background::#f5f7fa;

//body{
    height:100vh;
    display:flex;
    justify-content:center;
    align-items:center;
    background:
    radial-gradient(circle at top left,#38bdf8 0%,transparent 30%),
    radial-gradient(circle at bottom right,#1d4ed8 0%,transparent 30%),
    linear-gradient(135deg,#0f172a,#111827,#1e3a8a);
}

}

.contact-box{
width:500px;
background:#fff;
padding:40px;
border-radius:20px;
box-shadow:0 15px 40px rgba(0,0,0,0.15);
    border:1px solid #e5e7eb;
}

.contact-box h1{
text-align:center;
color:#0f4c81;
margin-bottom:10px;
}

.contact-box h3{
text-align:center;
color:#555;
margin-bottom:30px;
}

.info{
margin:18px 0;
font-size:18px;
color:#333;
}

.info i{
color:#1976d2;
width:30px;
}

.back{
display:block;
text-align:center;
margin-top:30px;
padding:14px;
background:#1976d2;
color:#fff;
text-decoration:none;
border-radius:10px;
font-weight:bold;
transition:.3s;
}

.back:hover{
background:#0d47a1;
}

</style>

</head>

<body>

<div class="contact-box">

<h1>Contact Us</h1>
<h3>WEAR ZONE</h3>

<div class="info">
<i class="fa-solid fa-location-dot"></i>
Savarkundla, Amreli, Gujarat
</div>

<div class="info">
<i class="fa-solid fa-phone"></i>
+91 94845 46225
</div>

<div class="info">
<i class="fa-solid fa-phone"></i>
+91 63521 54133
</div>

<div class="info">
<i class="fa-solid fa-envelope"></i>
wearzone@gmail.com
</div>

<div class="info">
<i class="fa-regular fa-clock"></i>
Monday - Saturday (9:00 AM - 8:00 PM)
</div>

<div class="info" style="margin-top:25px;line-height:28px;">
Thank you for visiting <b>WearZone</b>. If you have any questions regarding products, orders or services, feel free to contact us. Our team is always ready to help you.
</div>

<a href="index.php" class="back">
<i class="fa-solid fa-house"></i> Back to Home
</a>

</div>

</body>
</html>