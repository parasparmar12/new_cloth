<?php
$conn = mysqli_connect("localhost","root","","wearzone");

if(!$conn)
{
    die("Connection Failed: " . mysqli_connect_error());
}
?>