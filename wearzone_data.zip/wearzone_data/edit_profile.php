```php
<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

include("db.php");

$user_id = $_SESSION['user_id'];


// GET USER DATA
$query = mysqli_query(
    $conn,
    "SELECT * FROM users WHERE id='$user_id'"
);

if (mysqli_num_rows($query) == 0) {
    echo "User not found";
    exit();
}

$user = mysqli_fetch_assoc($query);


// UPDATE PROFILE
if (isset($_POST['update_profile'])) {

    $username = mysqli_real_escape_string(
        $conn,
        $_POST['username']
    );

    $email = mysqli_real_escape_string(
        $conn,
        $_POST['email']
    );

    $mobile = mysqli_real_escape_string(
        $conn,
        $_POST['mobile']
    );

    $address = mysqli_real_escape_string(
        $conn,
        $_POST['address']
    );


    // UPDATE DATABASE

    $update = mysqli_query(
        $conn,
        "UPDATE users SET
        username='$username',
        email='$email',
        mobile='$mobile',
        address='$address'
        WHERE id='$user_id'"
    );


    if ($update) {

        // Update session username
        $_SESSION['username'] = $username;

        echo "<script>
                alert('Profile Updated Successfully');
                window.location='profile.php';
              </script>";

        exit();

    } else {

        $error = "Profile update failed: " . mysqli_error($conn);
    }
}

?>

<!DOCTYPE html>
<html>

<head>

    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Edit Profile - WEAR ZONE</title>


    <style>

        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background: #f4f4f4;
        }


        /* NAVBAR */

        .navbar {
            background: #111;
            padding: 18px 40px;
        }

        .navbar a {
            color: white;
            text-decoration: none;
            margin-right: 25px;
            font-size: 16px;
        }

        .navbar a:hover {
            color: red;
        }


        /* CONTAINER */

        .container {
            width: 500px;
            margin: 40px auto;
            background: white;
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 5px 20px rgba(0,0,0,.15);
        }


        h2 {
            text-align: center;
            margin-bottom: 25px;
        }


        /* FORM */

        label {
            display: block;
            margin-bottom: 7px;
            font-weight: bold;
            color: #444;
        }


        input,
        textarea {

            width: 100%;
            padding: 12px;

            margin-bottom: 18px;

            border: 1px solid #ccc;

            border-radius: 7px;

            box-sizing: border-box;

            font-size: 15px;
        }


        textarea {

            height: 100px;

            resize: vertical;
        }


        input:focus,
        textarea:focus {

            border-color: #111;

            outline: none;
        }


        /* BUTTON */

        button {

            width: 100%;

            padding: 13px;

            background: #111;

            color: white;

            border: none;

            border-radius: 7px;

            font-size: 16px;

            cursor: pointer;
        }


        button:hover {

            background: red;
        }


        /* ERROR */

        .error {

            background: #ffd6d6;

            color: red;

            padding: 10px;

            border-radius: 6px;

            margin-bottom: 15px;

            text-align: center;
        }


        /* BACK */

        .back {

            display: block;

            text-align: center;

            margin-top: 18px;

            color: #555;

            text-decoration: none;
        }


        .back:hover {

            color: red;
        }

    </style>

</head>


<body>


<!-- NAVBAR -->

<div class="navbar">

    <a href="index.php">
        🏠 Home
    </a>

    <a href="view_cart.php">
        🛒 Cart
    </a>

    <a href="my_orders.php">
        📦 My Orders
    </a>

    <a href="profile.php">
        👤 Profile
    </a>

    <a href="logout.php">
        🚪 Logout
    </a>

</div>


<!-- EDIT PROFILE -->

<div class="container">

    <h2>
        ✏️ Edit Profile
    </h2>


    <?php

    if (isset($error)) {

    ?>

        <div class="error">

            <?php
            echo $error;
            ?>

        </div>

    <?php

    }

    ?>


    <form method="POST">


        <!-- USERNAME -->

        <label>
            Name
        </label>

        <input
            type="text"
            name="username"
            value="<?php echo htmlspecialchars($user['username']); ?>"
            required
        >


        <!-- EMAIL -->

        <label>
            Email
        </label>

        <input
            type="email"
            name="email"
            value="<?php echo htmlspecialchars($user['email']); ?>"
            required
        >


        <!-- MOBILE -->

        <label>
            Mobile
        </label>

        <input
            type="text"
            name="mobile"
            value="<?php echo isset($user['mobile']) ? htmlspecialchars($user['mobile']) : ''; ?>"
            placeholder="Enter mobile number"
        >


        <!-- ADDRESS -->

        <label>
            Address
        </label>

        <textarea
            name="address"
            placeholder="Enter your address"
        ><?php echo isset($user['address']) ? htmlspecialchars($user['address']) : ''; ?></textarea>


        <!-- UPDATE BUTTON -->

        <button
            type="submit"
            name="update_profile">

            💾 Update Profile

        </button>

    </form>


    <a
        href="profile.php"
        class="back">

        ← Back to Profile

    </a>

</div>


</body>

</html>
```
