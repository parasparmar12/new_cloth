<?php
include 'db.php';

$message = "";

if(isset($_POST['reset']))
{
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $new_password = $_POST['new_password'];
    $confirm_password = $_POST['confirm_password'];

    if($new_password != $confirm_password)
    {
        $message = "Passwords do not match!";
    }
    else
    {
        $check = mysqli_query($conn, "SELECT * FROM users WHERE email='$email'");

        if(mysqli_num_rows($check) > 0)
        {
            $password = password_hash($new_password, PASSWORD_DEFAULT);

            mysqli_query($conn, "UPDATE users SET password='$password' WHERE email='$email'");

            $message = "Password updated successfully!";
        }
        else
        {
            $message = "Email not found!";
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Forgot Password</title>

    <style>
    body{
        margin:0;
        padding:0;
        background:#f5f5f5;
        font-family:Arial;
    }

    .box{
        width:380px;
        background:white;
        margin:80px auto;
        padding:30px;
        border-radius:10px;
        box-shadow:0 0 15px rgba(0,0,0,.2);
    }

    h2{
        text-align:center;
    }

    input{
        width:100%;
        padding:12px;
        margin:10px 0;
        border:1px solid #ccc;
        border-radius:5px;
    }

    button{
        width:100%;
        padding:12px;
        background:#007BFF;
        color:white;
        border:none;
        border-radius:5px;
        cursor:pointer;
    }

    button:hover{
        background:#0056b3;
    }

    .msg{
        text-align:center;
        color:red;
        margin-bottom:10px;
    }

    a{
        text-decoration:none;
        color:#007BFF;
    }
    </style>

</head>
<body>

<div class="box">

<h2>Forgot Password</h2>

<div class="msg"><?php echo $message; ?></div>

<form method="POST">

<input type="email" name="email" placeholder="Enter Email" required>

<input type="password" name="new_password" placeholder="New Password" required>

<input type="password" name="confirm_password" placeholder="Confirm Password" required>

<button type="submit" name="reset">Reset Password</button>

</form>

<br>

<center>
<a href="login.php">Back to Login</a>
</center>

</div>

</body>
</html>