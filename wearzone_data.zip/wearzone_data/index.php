```php
<?php
session_start();
include 'db.php';

$selected_category = isset($_GET['category'])
    ? trim($_GET['category'])
    : '';

$category_map = [
    'T-Shirts' => 'T-Shirt',
    'Shirts'   => 'Shirt',
    'Kurta'   => 'Kurta'
];

$product_category = '';

if (isset($category_map[$selected_category])) {
    $product_category = $category_map[$selected_category];
}
?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>WEAR ZONE</title>

<link rel="stylesheet" href="style.css">

<link rel="stylesheet"
href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">

<style>

.wz-products-section {
    padding: 70px 5%;
    background: #fff;
}

.wz-products-heading {
    text-align: center;
    margin-bottom: 45px;
}

.wz-products-heading h2 {
    font-size: 36px;
    font-weight: 600;
    margin: 0 0 10px;
    color: #111;
    letter-spacing: 1px;
}

.wz-products-heading p {
    color: #777;
    font-size: 15px;
    margin: 0;
}

.wz-product-grid {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 28px;
    max-width: 1400px;
    margin: auto;
}

.wz-product-card {
    position: relative;
    background: #fff;
    overflow: hidden;
    transition: all 0.3s ease;
}

.wz-product-card:hover {
    transform: translateY(-5px);
}

.wz-product-image {
    position: relative;
    width: 100%;
    height: 410px;
    overflow: hidden;
    background: #f5f5f5;
    cursor: pointer;
}

.wz-product-image img {
    width: 100%;
    height: 100%;
    object-fit: cover;
    display: block;
    transition: transform 0.6s ease;
}

.wz-product-card:hover .wz-product-image img {
    transform: scale(1.06);
}

.wz-discount {
    position: absolute;
    top: 14px;
    left: 14px;
    background: #111;
    color: #fff;
    padding: 7px 11px;
    font-size: 12px;
    font-weight: 600;
    letter-spacing: .5px;
    z-index: 2;
}

.wz-wishlist {
    position: absolute;
    top: 13px;
    right: 13px;
    width: 40px;
    height: 40px;
    border-radius: 50%;
    background: rgba(255,255,255,0.95);
    border: none;
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    z-index: 3;
    font-size: 18px;
    color: #222;
    transition: all .3s ease;
}

.wz-wishlist:hover {
    background: #111;
    color: #fff;
}

.wz-wishlist .fas {
    color: #e91e63;
}

.wz-product-info {
    padding: 18px 4px 5px;
}

.wz-category {
    color: #888;
    font-size: 12px;
    text-transform: uppercase;
    letter-spacing: 1px;
    margin-bottom: 7px;
}

.wz-product-name {
    color: #111;
    font-size: 17px;
    font-weight: 500;
    margin: 0 0 9px;
    line-height: 1.4;
}

.wz-price {
    display: flex;
    align-items: center;
    gap: 9px;
    margin-bottom: 7px;
}

.wz-old-price {
    color: #999;
    font-size: 14px;
}

.wz-new-price,
.wz-normal-price {
    color: #111;
    font-size: 17px;
    font-weight: 600;
}

.wz-stock {
    font-size: 12px;
    color: #777;
}

.wz-view-details {
    margin-top: 14px;
    display: inline-flex;
    align-items: center;
    gap: 7px;
    color: #111;
    text-decoration: none;
    font-size: 13px;
    font-weight: 600;
    border-bottom: 1px solid #111;
    padding-bottom: 3px;
    transition: all .3s ease;
}

.wz-view-details:hover {
    gap: 12px;
}

.navbar .menu li a.active {
    font-weight: 700;
}

@media (max-width: 1100px) {

    .wz-product-grid {
        grid-template-columns: repeat(3, 1fr);
    }

    .wz-product-image {
        height: 350px;
    }
}

@media (max-width: 800px) {

    .wz-product-grid {
        grid-template-columns: repeat(2, 1fr);
        gap: 18px;
    }

    .wz-product-image {
        height: 330px;
    }

    .wz-products-heading h2 {
        font-size: 30px;
    }
}

@media (max-width: 500px) {

    .wz-products-section {
        padding: 45px 15px;
    }

    .wz-product-grid {
        grid-template-columns: repeat(2, 1fr);
        gap: 14px;
    }

    .wz-product-image {
        height: 250px;
    }

    .wz-product-info {
        padding-top: 12px;
    }

    .wz-product-name {
        font-size: 14px;
    }

    .wz-category {
        font-size: 10px;
    }

    .wz-new-price,
    .wz-normal-price {
        font-size: 14px;
    }

    .wz-old-price {
        font-size: 11px;
    }

    .wz-view-details {
        font-size: 11px;
    }

    .wz-wishlist {
        width: 34px;
        height: 34px;
        font-size: 15px;
    }
}

</style>
</head>

<body>

<header>

<nav class="navbar">

    <div class="logo">

        <img
            src="images/logo.png"
            alt="Wear Zone Logo"
        >

        <span>
            WEAR <span class="red">ZONE</span>
        </span>

    </div>

    <ul class="menu">

        <li>
            <a
                href="index.php"
                class="<?php echo ($selected_category === '') ? 'active' : ''; ?>"
            >
                Trending
            </a>
        </li>

        <li>
            <a
                href="index.php?category=T-Shirts"
                class="<?php echo ($selected_category === 'T-Shirts') ? 'active' : ''; ?>"
            >
                T-Shirts
            </a>
        </li>

        <li>
            <a
                href="index.php?category=Shirts"
                class="<?php echo ($selected_category === 'Shirts') ? 'active' : ''; ?>"
            >
                Shirts
            </a>
        </li>

        <li>
            <a
                href="index.php?category=Kurata"
                class="<?php echo ($selected_category === 'Kurta') ? 'active' : ''; ?>"
            >
                Kurta
            </a>
        </li>

        <li>
            <a href="contact.php">
                Contact
            </a>
        </li>

        <li>
            <a href="about.php">
                About Us
            </a>
        </li>

    </ul>

    <div class="icons">

        <i class="fas fa-search"></i>

        <?php if (isset($_SESSION['user_id'])) { ?>

            <a
                href="wishlist.php"
                style="color:white;font-size:22px;text-decoration:none;"
                title="Wishlist"
            >
                <i class="far fa-heart"></i>
            </a>

            <a
                href="view_cart.php"
                style="color:white;font-size:22px;text-decoration:none;"
                title="Shopping Cart"
            >
                <i class="fas fa-shopping-cart"></i>
            </a>

            <a
                href="profile.php"
                style="color:white;font-size:22px;text-decoration:none;"
                title="My Profile"
            >
                <i class="fas fa-user"></i>
            </a>

            <a
                href="logout.php"
                class="btn btn-dark"
            >
                Logout
            </a>

        <?php } else { ?>

            <a
                href="login.php"
                style="color:white;font-size:22px;text-decoration:none;"
                title="Login to use Wishlist"
            >
                <i class="far fa-heart"></i>
            </a>

            <a
                href="login.php"
                style="color:white;font-size:22px;text-decoration:none;"
                title="Login to use Cart"
            >
                <i class="fas fa-shopping-cart"></i>
            </a>

            <a
                href="login.php"
                class="btn btn-dark"
            >
                Login
            </a>

        <?php } ?>

    </div>

</nav>

</header>

<section class="hero">

    <video
        autoplay
        muted
        loop
        playsinline
        class="hero-video"
    >

        <source
            src="video/hero.mp4"
            type="video/mp4"
        >

        Your browser does not support the video tag.

    </video>

    <div class="hero-overlay"></div>

    <div class="overlay">

        <h1>
            NEW MEN'S COLLECTION
        </h1>

        <p>
            Premium Fashion For Every Occasion
        </p>

        <button
            onclick="document.querySelector('.wz-products-section').scrollIntoView({behavior:'smooth'});"
        >
            SHOP NOW
        </button>

    </div>

</section>

<section class="wz-products-section">

    <div class="wz-products-heading">

        <?php if ($selected_category !== '') { ?>

            <h2>
                <?php echo htmlspecialchars($selected_category); ?>
            </h2>

            <p>
                Discover our latest
                <?php echo htmlspecialchars($selected_category); ?>
                collection
            </p>

        <?php } else { ?>

            <h2>
                Our Products
            </h2>

            <p>
                Discover our latest collection
            </p>

        <?php } ?>

    </div>

    <div class="wz-product-grid">

        <?php

        if ($product_category !== '') {

            $category_safe = mysqli_real_escape_string(
                $conn,
                $product_category
            );

            $sql = "SELECT products.*, offers.offer_name, offers.discount
                    FROM products
                    LEFT JOIN offers
                    ON products.id = offers.product_id
                    AND CURDATE() BETWEEN offers.start_date AND offers.end_date
                    WHERE products.category = '$category_safe'
                    ORDER BY products.id DESC";

        } else {

            $sql = "SELECT products.*, offers.offer_name, offers.discount
                    FROM products
                    LEFT JOIN offers
                    ON products.id = offers.product_id
                    AND CURDATE() BETWEEN offers.start_date AND offers.end_date
                    ORDER BY products.id DESC";
        }

        $result = mysqli_query($conn, $sql);

        if ($result && mysqli_num_rows($result) > 0) {

            while ($row = mysqli_fetch_assoc($result)) {

                $original_price = (float)$row['price'];

                $discount = !empty($row['discount'])
                    ? (float)$row['discount']
                    : 0;

                $final_price = $original_price;

                if ($discount > 0) {

                    $final_price =
                        $original_price -
                        (($original_price * $discount) / 100);
                }

        ?>

        <div class="wz-product-card">

            <a
                href="product_details.php?id=<?php echo (int)$row['id']; ?>"
                style="display:block;text-decoration:none;"
            >

                <div class="wz-product-image">

                    <?php if ($discount > 0) { ?>

                        <span class="wz-discount">
                            <?php echo number_format($discount, 0); ?>% OFF
                        </span>

                    <?php } ?>

                    <?php if (!empty($row['image'])) { ?>

                        <img
                            src="uploads/<?php echo htmlspecialchars($row['image']); ?>"
                            alt="<?php echo htmlspecialchars($row['product_name']); ?>"
                        >

                    <?php } else { ?>

                        <div
                            style="
                                width:100%;
                                height:100%;
                                display:flex;
                                align-items:center;
                                justify-content:center;
                                color:#999;
                                font-size:14px;
                            "
                        >
                            No Image
                        </div>

                    <?php } ?>

                </div>

            </a>

            <?php if (isset($_SESSION['user_id'])) { ?>

                <button
                    type="button"
                    class="wz-wishlist wishlist-btn"
                    data-product-id="<?php echo (int)$row['id']; ?>"
                    title="Add to Wishlist"
                >
                    <i class="far fa-heart"></i>
                </button>

            <?php } else { ?>

                <a
                    href="login.php"
                    class="wz-wishlist"
                    title="Login to use Wishlist"
                >
                    <i class="far fa-heart"></i>
                </a>

            <?php } ?>

            <div class="wz-product-info">

                <div class="wz-category">
                    <?php echo htmlspecialchars($row['category']); ?>
                </div>

                <h3 class="wz-product-name">
                    <?php echo htmlspecialchars($row['product_name']); ?>
                </h3>

                <?php if ($discount > 0) { ?>

                    <div class="wz-price">

                        <del class="wz-old-price">
                            ₹<?php echo number_format($original_price, 2); ?>
                        </del>

                        <span class="wz-new-price">
                            ₹<?php echo number_format($final_price, 2); ?>
                        </span>

                    </div>

                <?php } else { ?>

                    <div class="wz-price">

                        <span class="wz-normal-price">
                            ₹<?php echo number_format($original_price, 2); ?>
                        </span>

                    </div>

                <?php } ?>

                <div class="wz-stock">
                    Stock:
                    <?php echo htmlspecialchars($row['stock']); ?>
                </div>

                <a
                    href="product_details.php?id=<?php echo (int)$row['id']; ?>"
                    class="wz-view-details"
                >
                    View Details
                    <i class="fas fa-arrow-right"></i>
                </a>

            </div>

        </div>

        <?php

            }

        } else {

        ?>

        <div
            style="
                grid-column:1/-1;
                text-align:center;
                padding:60px 20px;
            "
        >

            <h3>
                No Products Found
            </h3>

            <p style="color:#777;">

                <?php if ($selected_category !== '') { ?>

                    No products available in
                    <?php echo htmlspecialchars($selected_category); ?>
                    category.

                <?php } else { ?>

                    Please add products from the admin panel.

                <?php } ?>

            </p>

        </div>

        <?php } ?>

    </div>

</section>

<script src="script.js"></script>

<script>

document.querySelectorAll(".wishlist-btn").forEach(function(button) {

    button.addEventListener("click", function(event) {

        event.preventDefault();
        event.stopPropagation();

        let productId =
            this.getAttribute("data-product-id");

        let heart =
            this.querySelector("i");

        let formData =
            new FormData();

        formData.append("product_id", productId);

        fetch("add_to_wishlist.php", {
            method: "POST",
            body: formData
        })

        .then(function(response) {
            return response.json();
        })

        .then(function(data) {

            if (data.status === "success") {

                heart.classList.remove("far");
                heart.classList.add("fas");

                alert("Product Added to Wishlist ❤️");

            } else if (data.status === "exists") {

                alert("Product already in Wishlist ❤️");

            } else if (data.status === "login") {

                window.location.href = "login.php";

            } else {

                alert(
                    data.message ||
                    "Something went wrong"
                );

            }

        })

        .catch(function(error) {

            console.log(error);

            alert("Something went wrong");

        });

    });

});

</script>

</body>
</html>
