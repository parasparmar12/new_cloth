<?php

session_start();

include 'db.php';
if (isset($_GET['product_id'])) {
    $_SESSION['login_product_id'] = intval($_GET['product_id']);
}

if(isset($_POST['login']))
{

    $email = mysqli_real_escape_string(
        $conn,
        $_POST['email']
    );

    $password = $_POST['password'];


    $q = mysqli_query(
        $conn,
        "SELECT * FROM users WHERE email='$email'"
    );


    if(mysqli_num_rows($q) > 0)
    {

        $row = mysqli_fetch_assoc($q);


        if(password_verify($password, $row['password']))
        {

            /* LOGIN SESSION */

            $_SESSION['username'] = $row['username'];

            $_SESSION['user_id'] = $row['id'];


            /*
            ==========================================
            ADD SELECTED PRODUCT TO CART AFTER LOGIN
            ==========================================
            */

            if(isset($_SESSION['login_product_id']))
            {

                $product_id = intval(
                    $_SESSION['login_product_id']
                );


                /* CHECK PRODUCT EXISTS */

                $product_check = mysqli_query(
                    $conn,
                    "SELECT id FROM products WHERE id='$product_id'"
                );


                if(mysqli_num_rows($product_check) > 0)
                {

                    /* CHECK ALREADY IN CART */

                    $cart_check = mysqli_query(
                        $conn,
                        "SELECT id, quantity
                         FROM cart
                         WHERE user_id='{$row['id']}'
                         AND product_id='$product_id'"
                    );


                    if(mysqli_num_rows($cart_check) > 0)
                    {

                        /* INCREASE QUANTITY */

                        $cart_row = mysqli_fetch_assoc(
                            $cart_check
                        );

                        $new_quantity =
                            $cart_row['quantity'] + 1;


                        mysqli_query(
                            $conn,
                            "UPDATE cart
                             SET quantity='$new_quantity'
                             WHERE id='{$cart_row['id']}'"
                        );

                    }
                    else
                    {

                        /* ADD NEW PRODUCT */

                        mysqli_query(
                            $conn,
                            "INSERT INTO cart
                            (user_id, product_id, quantity)
                            VALUES
                            ('{$row['id']}', '$product_id', '1')"
                        );

                    }

                }


                /* REMOVE TEMP PRODUCT ID */

                unset($_SESSION['login_product_id']);


                /* GO TO CART */

                header("Location: view_cart.php");
                exit();

            }


            /*
            ==========================================
            NORMAL LOGIN REDIRECT
            ==========================================
            */

            if(isset($_SESSION['redirect_url']))
            {

                $redirect = $_SESSION['redirect_url'];

                unset($_SESSION['redirect_url']);


                header("Location: " . $redirect);
                exit();

            }
            else
            {

                header("Location: index.php");
                exit();

            }

        }
        else
        {

            $error = "Invalid Email or Password";

        }

    }
    else
    {

        $error = "Invalid Email or Password";

    }

}

?>


<!DOCTYPE html>

<html>

<head>

<meta charset="UTF-8">

<meta
    name="viewport"
    content="width=device-width,initial-scale=1"
>

<title>Fashion Login</title>


<link
    href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap"
    rel="stylesheet"
>


<style>

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family:Poppins,sans-serif;
}


body{

    min-height:100vh;

    display:flex;

    justify-content:center;

    align-items:center;

    background:#f5f5f5;

}


.box{

    width:430px;

    background:#ffffff;

    padding:45px;

    border-radius:20px;

    box-shadow:
        0 20px 60px rgba(0,0,0,0.25);

    border:1px solid #e5e7eb;

    text-align:center;

    transition:0.3s;

}


.box:hover{

    transform:translateY(-5px);

    box-shadow:
        0 30px 70px rgba(0,0,0,0.35);

}


h1{

    text-align:center;

    margin-bottom:25px;

    font-weight:600;

}


h2{

    text-align:center;

    color:#4a63e7;

    margin-top:10px;

    margin-bottom:8px;

    font-size:28px;

}


.login-msg{

    text-align:center;

    color:#666;

    font-size:16px;

    margin-bottom:30px;

    line-height:1.6;

}


input{

    width:100%;

    padding:15px;

    margin:15px 0;

    border:1px solid #ccc;

    border-radius:10px;

    outline:none;

    font-size:16px;

    transition:0.3s;

}


input:focus{

    border:2px solid #4a63e7;

    box-shadow:
        0 0 8px rgba(74,99,231,0.3);

}


button{

    width:100%;

    padding:14px;

    background:#ff4d57;

    color:#fff;

    border:none;

    border-radius:6px;

    font-size:16px;

    font-weight:600;

    cursor:pointer;

}


button:hover{

    background:#e63946;

}


.links{

    text-align:center;

    margin-top:15px;

}


.err{

    color:red;

    text-align:center;

    margin-bottom:10px;

}

</style>

</head>


<body>


<form
    class="box"
    method="post"
>


<h1>Fashion Login</h1>


<h2>Welcome Back!</h2>


<p class="login-msg">

Sign in to access your account
and continue shopping.

</p>


<?php

if(isset($error))
{

    echo "<div class='err'>$error</div>";

}

?>


<input
    type="email"
    name="email"
    placeholder="Enter your email"
    required
>


<input
    type="password"
    name="password"
    placeholder="Password"
    required
>


<button
    type="submit"
    name="login"
>

Login

</button>


<div class="links">

Forgot Your Password?

<a
    href="forgot_password.php"
    style="color:#007BFF;font-weight:bold;"
>

Forgot Password

</a>

<br><br>


New User? Create an Account

<a
    href="register.php"
    style="color:dodgerblue;font-weight:bold;"
>

Register

</a>

</div>


</form>


</body>

</html>