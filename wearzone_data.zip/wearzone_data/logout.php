<?php
session_start();

// Remove all session data
session_unset();
session_destroy();

// Back to Home Page
header("Location: index.php");
exit();
?>