<?php

session_start();
include("db.php");

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = intval($_SESSION['user_id']);

$sql = mysqli_query(
    $conn,
    "SELECT * FROM orders
     WHERE user_id='$user_id'
     ORDER BY id DESC"
);

?>

<!DOCTYPE html>
<html>

<head>

<title>My Orders - WEAR ZONE</title>

<style>

body{
    font-family:Arial,sans-serif;
    background:#f5f5f5;
    margin:0;
    padding:30px;
}

.container{
    width:95%;
    margin:auto;
}

h2{
    text-align:center;
    margin-bottom:30px;
}

table{
    width:100%;
    background:white;
    border-collapse:collapse;
    box-shadow:0 0 10px rgba(0,0,0,.2);
}

th,td{
    padding:15px;
    border:1px solid #ddd;
    text-align:center;
    vertical-align:middle;
}

th{
    background:#111;
    color:white;
}

.pending{
    color:orange;
    font-weight:bold;
}

.shipped{
    color:blue;
    font-weight:bold;
}

.delivered{
    color:green;
    font-weight:bold;
}

.cancelled{
    color:red;
    font-weight:bold;
}

.cancel-btn{
    display:inline-block;
    padding:8px 12px;
    background:red;
    color:white;
    text-decoration:none;
    border-radius:5px;
}

.cancel-btn:hover{
    background:darkred;
}

.back{
    display:inline-block;
    margin-top:20px;
    padding:12px 25px;
    background:#007bff;
    color:white;
    text-decoration:none;
    border-radius:6px;
}

.product-box{
    padding:10px;
    margin-bottom:10px;
    border-bottom:1px solid #ddd;
}

.product-box:last-child{
    border-bottom:none;
    margin-bottom:0;
}

.product-name{
    font-weight:bold;
    font-size:16px;
    margin-bottom:6px;
}

.size{
    display:inline-block;
    padding:5px 10px;
    background:#f1f1f1;
    border-radius:5px;
    font-weight:bold;
    margin-bottom:5px;
}

.quantity{
    color:#555;
    font-size:14px;
}

</style>

</head>

<body>

<div class="container">

<h2>📦 My Orders</h2>

<table>

<tr>

<th>Order ID</th>

<th>Product / Size / Quantity</th>

<th>Total</th>

<th>Status</th>

<th>Date</th>

<th>Address</th>

<th>Action</th>

</tr>

<?php

if ($sql && mysqli_num_rows($sql) > 0) {

    while ($row = mysqli_fetch_assoc($sql)) {

        $order_id = intval($row['id']);

        $items = mysqli_query(
            $conn,
            "SELECT product_name, size, quantity
             FROM order_items
             WHERE order_id='$order_id'"
        );

?>

<tr>

<td>
#WZ<?php echo $order_id; ?>
</td>

<td>

<?php

if ($items && mysqli_num_rows($items) > 0) {

    while ($item = mysqli_fetch_assoc($items)) {

?>

<div class="product-box">

    <div class="product-name">
        <?php echo htmlspecialchars($item['product_name']); ?>
    </div>

    <div class="size">
        Size: <?php echo htmlspecialchars($item['size']); ?>
    </div>

    <div class="quantity">
        Quantity: <?php echo intval($item['quantity']); ?>
    </div>

</div>

<?php

    }

} else {

    echo "No Product Details";

}

?>

</td>

<td>
₹<?php echo number_format($row['total'], 2); ?>
</td>

<td>

<?php

if ($row['status'] == "Pending") {

    echo "<span class='pending'>Pending</span>";

}
elseif ($row['status'] == "Shipped") {

    echo "<span class='shipped'>Shipped</span>";

}
elseif ($row['status'] == "Delivered") {

    echo "<span class='delivered'>Delivered</span>";

}
elseif ($row['status'] == "Cancelled") {

    echo "<span class='cancelled'>Cancelled</span>";

}
else {

    echo htmlspecialchars($row['status']);

}

?>

</td>

<td>
<?php echo htmlspecialchars($row['order_date']); ?>
</td>

<td>
<?php echo htmlspecialchars($row['address']); ?>
</td>

<td>

<?php

if ($row['status'] == "Pending") {

?>

<a
    href="cancel_order.php?id=<?php echo $order_id; ?>"
    class="cancel-btn"
    onclick="return confirm('Are you sure you want to cancel this order?');">

    ❌ Cancel Order

</a>

<?php

}
elseif ($row['status'] == "Cancelled") {

    echo "<span class='cancelled'>Cancelled</span>";

}
else {

    echo "<span style='color:#777;'>Not Available</span>";

}

?>

</td>

</tr>

<?php

    }

}
else {

?>

<tr>

<td colspan="7">

No Orders Found

</td>

</tr>

<?php

}

?>

</table>

<a href="index.php" class="back">

⬅ Continue Shopping

</a>

</div>

</body>

</html>