<?php

session_start();
include("db.php");


/* CHECK LOGIN */

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}


$user_id = $_SESSION['user_id'];


/* GET LAST ORDER */

$sql = mysqli_query($conn, "
    SELECT *
    FROM orders
    WHERE user_id = '$user_id'
    ORDER BY id DESC
    LIMIT 1
");


if (mysqli_num_rows($sql) > 0) {

    $order = mysqli_fetch_assoc($sql);

} else {

    header("Location: index.php");
    exit();

}

?>


<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Order Success - WEAR ZONE</title>


    <link
        rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">


    <style>

        * {
            box-sizing: border-box;
        }


        body {

            margin: 0;

            font-family: Arial, sans-serif;

            background: #f5f5f5;

            min-height: 100vh;

            display: flex;

            justify-content: center;

            align-items: center;

        }


        .success-box {

            width: 550px;

            max-width: 95%;

            background: #fff;

            padding: 40px;

            border-radius: 15px;

            text-align: center;

            box-shadow: 0 10px 25px rgba(0,0,0,.15);

        }


        .success-icon {

            font-size: 80px;

            color: #28a745;

        }


        .success-box h1 {

            color: #28a745;

            margin: 20px 0 10px;

        }


        .success-box > p {

            color: #555;

            font-size: 18px;

        }


        .order {

            background: #f8f8f8;

            padding: 20px;

            border-radius: 10px;

            margin: 25px 0;

            text-align: left;

        }


        .order p {

            margin: 12px 0;

            font-size: 16px;

        }


        .order-id {

            color: #007bff;

        }


        .total {

            color: green;

            font-size: 20px;

        }


        .status {

            color: orange;

            font-weight: bold;

        }


        .payment {

            color: #333;

            font-weight: bold;

        }


        .btn {

            display: inline-block;

            text-decoration: none;

            padding: 12px 25px;

            margin: 8px;

            border-radius: 8px;

            color: #fff;

            font-weight: bold;

        }


        .shop {

            background: #007bff;

        }


        .orders {

            background: #28a745;

        }


        .btn:hover {

            opacity: .85;

        }

    </style>

</head>


<body>


<div class="success-box">


    <!-- SUCCESS ICON -->

    <i class="fa-solid fa-circle-check success-icon"></i>


    <h1>
        Order Confirmed!
    </h1>


    <p>
        Thank you for shopping with <b>WearZone</b> ❤️
    </p>


    <div class="order">


        <!-- ORDER ID -->

        <p>

            <b>Order ID :</b>

            <span class="order-id">

                #WZ<?= $order['id']; ?>

            </span>

        </p>


        <!-- CUSTOMER -->

        <p>

            <b>Customer :</b>

            <?= htmlspecialchars($order['customer_name']); ?>

        </p>


        <!-- TOTAL -->

        <p>

            <b>Total :</b>

            <span class="total">

                ₹<?= number_format($order['total'], 2); ?>

            </span>

        </p>


        <!-- PAYMENT -->

        <p>

            <b>Payment :</b>

            <span class="payment">

                <?= htmlspecialchars($order['payment_method']); ?>

            </span>

        </p>


        <!-- STATUS -->

        <p>

            <b>Status :</b>

            <span class="status">

                <?= htmlspecialchars($order['status']); ?> ⏳

            </span>

        </p>


        <!-- DATE -->

        <p>

            <b>Order Date :</b>

            <?= date(
                "d M Y, h:i A",
                strtotime($order['order_date'])
            ); ?>

        </p>


        <!-- DELIVERY -->

        <p>

            <b>Estimated Delivery :</b>

            3 - 5 Business Days 🚚

        </p>


    </div>


    <!-- BUTTONS -->

    <a
        href="index.php"
        class="btn shop">

        🛍️ Continue Shopping

    </a>


    <a
        href="my_orders.php"
        class="btn orders">

        📦 View My Orders

    </a>


</div>


</body>

</html>