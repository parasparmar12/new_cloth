<?php

session_start();
include("db.php");

/* ================= CHECK LOGIN ================= */

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = intval($_SESSION['user_id']);

/* ================= CHECK FORM ================= */

if (
    !isset($_POST['customer_name']) ||
    !isset($_POST['mobile']) ||
    !isset($_POST['address']) ||
    !isset($_POST['payment_method'])
) {
    header("Location: checkout.php");
    exit();
}

/* ================= GET FORM DATA ================= */

$customer_name = mysqli_real_escape_string($conn, trim($_POST['customer_name']));
$mobile = mysqli_real_escape_string($conn, trim($_POST['mobile']));
$address = mysqli_real_escape_string($conn, trim($_POST['address']));
$payment_method = mysqli_real_escape_string($conn, trim($_POST['payment_method']));

/* ================= GET CART ================= */

$cart = mysqli_query($conn, "
    SELECT
        cart.product_id,
        cart.quantity,
        cart.size,
        products.product_name,
        products.price,
        products.image
    FROM cart
    INNER JOIN products ON cart.product_id = products.id
    WHERE cart.user_id = '$user_id'
");

if (!$cart || mysqli_num_rows($cart) == 0) {
    echo "<script>
            alert('Your cart is empty!');
            window.location='view_cart.php';
          </script>";
    exit();
}

/* ================= CALCULATE ORIGINAL TOTAL ================= */

$total = 0;
$cart_items = [];

while ($row = mysqli_fetch_assoc($cart)) {

    $item_total = floatval($row['price']) * intval($row['quantity']);

    $total += $item_total;

    $cart_items[] = $row;
}

/* ================= RECHECK COUPON ================= */
/* Do not blindly trust the session discount. Recalculate it from DB. */

$coupon_discount = 0;
$coupon_code = trim($_SESSION['coupon_code'] ?? '');

if ($coupon_code !== '') {

    $coupon_code_db = mysqli_real_escape_string($conn, $coupon_code);

    $coupon_query = mysqli_query($conn, "
        SELECT *
        FROM coupons
        WHERE UPPER(TRIM(coupon_code)) = UPPER('$coupon_code_db')
        AND LOWER(TRIM(status)) = 'active'
        LIMIT 1
    ");

    if ($coupon_query && mysqli_num_rows($coupon_query) > 0) {

        $coupon = mysqli_fetch_assoc($coupon_query);

        /* Normalize DB date values to Y-m-d */

        $start_date = date('Y-m-d', strtotime($coupon['start_date']));
        $end_date = date('Y-m-d', strtotime($coupon['end_date']));
        $today = date('Y-m-d');

        if (
            $today >= $start_date &&
            $today <= $end_date &&
            $total >= floatval($coupon['min_order_amount'])
        ) {

            if ($coupon['discount_type'] === 'percentage') {

                $coupon_discount =
                    ($total * floatval($coupon['discount_value'])) / 100;

            } else {

                $coupon_discount =
                    floatval($coupon['discount_value']);
            }

            if ($coupon_discount > $total) {
                $coupon_discount = $total;
            }

        } else {

            /* Coupon is no longer valid for this order */

            unset($_SESSION['coupon_code']);
            unset($_SESSION['coupon_discount']);

            $coupon_code = '';
        }

    } else {

        unset($_SESSION['coupon_code']);
        unset($_SESSION['coupon_discount']);

        $coupon_code = '';
    }
}

/* ================= FINAL TOTAL ================= */

$final_total = $total - $coupon_discount;

if ($final_total < 0) {
    $final_total = 0;
}

/* ================= CREATE ORDER ================= */

$order_sql = "
    INSERT INTO orders
    (
        user_id,
        total,
        customer_name,
        mobile,
        address,
        status,
        payment_method
    )
    VALUES
    (
        '$user_id',
        '$final_total',
        '$customer_name',
        '$mobile',
        '$address',
        'Pending',
        '$payment_method'
    )
";

if (mysqli_query($conn, $order_sql)) {

    $order_id = mysqli_insert_id($conn);

    /* ================= INSERT ORDER ITEMS ================= */

    foreach ($cart_items as $row) {

        $product_id = intval($row['product_id']);

        $product_name = mysqli_real_escape_string(
            $conn,
            $row['product_name']
        );

        $product_image = mysqli_real_escape_string(
            $conn,
            $row['image']
        );

        /* ================= GET SIZE ================= */

        $size = mysqli_real_escape_string(
            $conn,
            $row['size'] ?? ''
        );

        $price = floatval($row['price']);

        $qty = intval($row['quantity']);

        $item_total = $price * $qty;

        /* ================= INSERT ORDER ITEM ================= */

        $insert_item = mysqli_query($conn, "
            INSERT INTO order_items
            (
                order_id,
                product_id,
                product_name,
                product_image,
                price,
                quantity,
                total,
                size
            )
            VALUES
            (
                '$order_id',
                '$product_id',
                '$product_name',
                '$product_image',
                '$price',
                '$qty',
                '$item_total',
                '$size'
            )
        ");

        if (!$insert_item) {

            die(
                "Order item error: " .
                mysqli_error($conn)
            );
        }
    }

    /* ================= EMPTY CART ================= */

    mysqli_query(
        $conn,
        "DELETE FROM cart WHERE user_id='$user_id'"
    );

    /* ================= CLEAR COUPON ================= */

    unset($_SESSION['coupon_code']);
    unset($_SESSION['coupon_discount']);
    unset($_SESSION['coupon_success']);
    unset($_SESSION['coupon_error']);

    /* ================= SUCCESS ================= */

    header("Location: order_success.php");
    exit();

} else {

    echo "Order Error: " . mysqli_error($conn);
}

?>