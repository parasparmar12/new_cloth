<?php

session_start();
include 'db.php';

if (!isset($_GET['id']) || empty($_GET['id'])) {
    header("Location: index.php");
    exit();
}

$product_id = intval($_GET['id']);

$sql = "SELECT products.*, offers.offer_name, offers.discount
        FROM products
        LEFT JOIN offers
        ON products.id = offers.product_id
        AND CURDATE() BETWEEN offers.start_date AND offers.end_date
        WHERE products.id = '$product_id'
        LIMIT 1";

$result = mysqli_query($conn, $sql);

if (!$result || mysqli_num_rows($result) == 0) {
    echo "<script>
            alert('Product not found!');
            window.location='index.php';
          </script>";
    exit();
}

$product = mysqli_fetch_assoc($result);

$product_name = htmlspecialchars($product['product_name']);
$category = htmlspecialchars($product['category']);
$description = htmlspecialchars($product['description'] ?? '');
$image = htmlspecialchars($product['image'] ?? '');
$stock = (int)$product['stock'];
$original_price = (float)$product['price'];

$discount = !empty($product['discount'])
    ? (float)$product['discount']
    : 0;

$size_prices = [];

if (!empty($product['size_prices'])) {
    $decoded = json_decode($product['size_prices'], true);

    if (is_array($decoded)) {
        $size_prices = $decoded;
    }
}

if (empty($size_prices)) {
    $size_prices = [
        'S' => $original_price,
        'M' => $original_price,
        'L' => $original_price,
        'XL' => $original_price + 100,
        'XXL' => $original_price + 200
    ];
}

$default_size = 'M';

if (!isset($size_prices[$default_size])) {
    $default_size = array_key_first($size_prices);
}

$default_size_price = (float)$size_prices[$default_size];

$default_final_price = $default_size_price;

if ($discount > 0) {
    $default_final_price =
        $default_size_price -
        (($default_size_price * $discount) / 100);
}

?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title><?php echo $product_name; ?> - WEAR ZONE</title>

<link rel="stylesheet"
href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">

<style>

* {
    box-sizing: border-box;
}

body {
    margin: 0;
    font-family: Arial, Helvetica, sans-serif;
    background: #fff;
    color: #111;
}

header {
    background: #000;
}

.navbar {
    min-height: 75px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 10px 5%;
    gap: 20px;
}

.logo {
    display: flex;
    align-items: center;
    gap: 8px;
    color: white;
    font-size: 21px;
    font-weight: bold;
}

.logo img {
    width: 40px;
    height: 40px;
    object-fit: contain;
}

.red {
    color: #e53935;
}

.menu {
    display: flex;
    gap: 28px;
    list-style: none;
    margin: 0;
    padding: 0;
}

.menu a {
    color: white;
    text-decoration: none;
    font-size: 14px;
}

.menu a:hover {
    color: #ff3b30;
}

.icons {
    display: flex;
    align-items: center;
    gap: 18px;
}

.icons a {
    color: white;
    text-decoration: none;
}

.icons i {
    font-size: 19px;
}

.btn-dark {
    border: 1px solid white;
    padding: 8px 16px;
    font-size: 13px;
    border-radius: 4px;
}

.btn-dark:hover {
    background: white;
    color: black !important;
}

.details-page {
    max-width: 1200px;
    margin: auto;
    padding: 65px 25px;
}

.back-link {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    text-decoration: none;
    color: #555;
    margin-bottom: 35px;
    font-size: 14px;
}

.back-link:hover {
    color: #000;
}

.product-details {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 70px;
    align-items: start;
}

.main-image {
    position: relative;
    background: #f5f5f5;
    height: 650px;
    overflow: hidden;
}

.main-image img {
    width: 100%;
    height: 100%;
    object-fit: cover;
}

.discount {
    position: absolute;
    top: 18px;
    left: 18px;
    background: #111;
    color: white;
    padding: 9px 13px;
    font-size: 13px;
    font-weight: bold;
    z-index: 2;
}

.product-info {
    padding-top: 10px;
}

.category {
    font-size: 13px;
    color: #888;
    text-transform: uppercase;
    letter-spacing: 2px;
    margin-bottom: 14px;
}

.product-info h1 {
    font-size: 40px;
    line-height: 1.15;
    margin: 0 0 18px;
}

.price {
    display: flex;
    align-items: center;
    gap: 12px;
    margin-bottom: 25px;
}

.old-price {
    color: #999;
    font-size: 19px;
}

.final-price,
.normal-price {
    font-size: 27px;
    font-weight: bold;
}

.size-title {
    font-size: 15px;
    font-weight: bold;
    margin-bottom: 12px;
}

.size-options {
    display: flex;
    gap: 10px;
    flex-wrap: wrap;
    margin-bottom: 25px;
}

.size-btn {
    min-width: 55px;
    height: 44px;
    padding: 0 15px;
    background: white;
    border: 1px solid #bbb;
    color: #111;
    font-size: 14px;
    font-weight: bold;
    cursor: pointer;
    border-radius: 3px;
}

.size-btn:hover {
    border-color: #000;
}

.size-btn.active {
    background: #111;
    color: white;
    border-color: #111;
}

.description {
    color: #555;
    line-height: 1.8;
    font-size: 15px;
    margin-bottom: 25px;
    white-space: pre-line;
}

.stock {
    margin-bottom: 25px;
    font-size: 14px;
}

.quantity-title {
    font-size: 14px;
    font-weight: bold;
    margin-bottom: 9px;
}

.quantity-box {
    display: flex;
    align-items: center;
    width: 145px;
    height: 48px;
    border: 1px solid #ccc;
    margin-bottom: 20px;
}

.quantity-box button {
    width: 45px;
    height: 100%;
    border: none;
    background: white;
    font-size: 20px;
    cursor: pointer;
}

.quantity-box input {
    width: 55px;
    height: 100%;
    border: none;
    text-align: center;
    font-size: 16px;
    outline: none;
}

.actions {
    display: flex;
    gap: 10px;
    margin-bottom: 25px;
}

.add-cart {
    flex: 1;
    height: 52px;
    border: none;
    background: #111;
    color: white;
    font-weight: bold;
    cursor: pointer;
    text-decoration: none;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
}

.add-cart:hover {
    background: #333;
}

.wishlist {
    width: 55px;
    height: 52px;
    border: 1px solid #ccc;
    background: white;
    font-size: 21px;
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
}

.wishlist:hover {
    color: #e91e63;
    border-color: #e91e63;
}

.secure-info {
    border-top: 1px solid #eee;
    padding-top: 20px;
    color: #666;
    font-size: 13px;
    line-height: 2;
}

@media (max-width: 850px) {

    .navbar {
        flex-wrap: wrap;
        justify-content: center;
    }

    .menu {
        order: 3;
        width: 100%;
        justify-content: center;
        flex-wrap: wrap;
        gap: 15px;
    }

    .product-details {
        grid-template-columns: 1fr;
        gap: 35px;
    }

    .main-image {
        height: 500px;
    }

    .product-info h1 {
        font-size: 32px;
    }
}

@media (max-width: 500px) {

    .details-page {
        padding: 35px 15px;
    }

    .main-image {
        height: 400px;
    }

    .product-info h1 {
        font-size: 27px;
    }
}

</style>

</head>

<body>

<header>

<nav class="navbar">

<div class="logo">

<img src="images/logo.png" alt="Wear Zone Logo">

<span>
WEAR <span class="red">ZONE</span>
</span>

</div>

<ul class="menu">

<li>
<a href="index.php">Trending</a>
</li>

<li>
<a href="index.php?category=T-Shirts">T-Shirts</a>
</li>

<li>
<a href="index.php?category=Shirts">Shirts</a>
</li>

<li>
<a href="index.php?category=Kurata">Kurata</a>
</li>

<li>
<a href="contact.php">Contact</a>
</li>

<li>
<a href="about.php">About Us</a>
</li>

</ul>

<div class="icons">

<?php if (isset($_SESSION['user_id'])) { ?>

<a href="wishlist.php">
<i class="far fa-heart"></i>
</a>

<a href="view_cart.php">
<i class="fas fa-shopping-cart"></i>
</a>

<a href="profile.php">
<i class="fas fa-user"></i>
</a>

<a href="logout.php" class="btn-dark">
Logout
</a>

<?php } else { ?>

<a href="login.php">
<i class="far fa-heart"></i>
</a>

<a href="login.php">
<i class="fas fa-shopping-cart"></i>
</a>

<a href="login.php" class="btn-dark">
Login
</a>

<?php } ?>

</div>

</nav>

</header>

<main class="details-page">

<a href="index.php" class="back-link">

<i class="fas fa-arrow-left"></i>

Continue Shopping

</a>

<div class="product-details">

<div class="main-image">

<?php if ($discount > 0) { ?>

<div class="discount">

<?php
echo rtrim(
    rtrim(number_format($discount, 2), '0'),
    '.'
);
?>% OFF

</div>

<?php } ?>

<img
src="uploads/<?php echo $image; ?>"
alt="<?php echo $product_name; ?>">

</div>

<div class="product-info">

<div class="category">
<?php echo $category; ?>
</div>

<h1>
<?php echo $product_name; ?>
</h1>

<div class="price">

<?php if ($discount > 0) { ?>

<del class="old-price" id="oldPrice">

₹<?php echo number_format($default_size_price, 2); ?>

</del>

<span class="final-price" id="finalPrice">

₹<?php echo number_format($default_final_price, 2); ?>

</span>

<?php } else { ?>

<span class="normal-price" id="finalPrice">

₹<?php echo number_format($default_final_price, 2); ?>

</span>

<?php } ?>

</div>

<div class="size-title">
Select Size
</div>

<div class="size-options">

<?php foreach ($size_prices as $size => $size_price) { ?>

<button
type="button"
class="size-btn <?php echo ($size == $default_size) ? 'active' : ''; ?>"
data-size="<?php echo htmlspecialchars($size); ?>"
data-price="<?php echo (float)$size_price; ?>">

<?php echo htmlspecialchars($size); ?>

</button>

<?php } ?>

</div>

<?php if (!empty($description)) { ?>

<div class="description">
<?php echo $description; ?>
</div>

<?php } else { ?>

<div class="description">
Premium quality fashion product from WEAR ZONE.
</div>

<?php } ?>

<div class="stock">

<?php if ($stock > 0) { ?>

<strong>
<i class="fas fa-check"></i>
In Stock
</strong>

<br>

<?php echo $stock; ?> items available

<?php } else { ?>

<strong style="color:red;">
Out of Stock
</strong>

<?php } ?>

</div>

<?php if ($stock > 0) { ?>

<div class="quantity-title">
Quantity
</div>

<div class="quantity-box">

<button type="button" onclick="decreaseQty()">
−
</button>

<input
type="number"
id="quantity"
value="1"
min="1"
max="<?php echo $stock; ?>"
readonly>

<button type="button" onclick="increaseQty()">
+
</button>

</div>

<div class="actions">

<?php if (isset($_SESSION['user_id'])) { ?>

<a
href="add_to_cart.php?id=<?php echo $product_id; ?>&size=<?php echo urlencode($default_size); ?>"
class="add-cart"
id="addCartBtn">

<i class="fas fa-shopping-bag"></i>

Add To Cart

</a>

<button
type="button"
class="wishlist"
id="wishlistBtn">

<i class="far fa-heart"></i>

</button>

<?php } else { ?>

<a
href="login.php?product_id=<?php echo $product_id; ?>"
class="add-cart">

<i class="fas fa-shopping-bag"></i>

Login To Add To Cart

</a>

<a href="login.php" class="wishlist">

<i class="far fa-heart"></i>

</a>

<?php } ?>

</div>

<?php } else { ?>

<button
disabled
style="width:100%;height:52px;border:none;background:#ddd;color:#777;font-weight:bold;">

Out of Stock

</button>

<?php } ?>

<div class="secure-info">

<div>
<i class="fas fa-truck"></i>
Secure & reliable delivery
</div>

<div>
<i class="fas fa-rotate-left"></i>
Easy shopping experience
</div>

<div>
<i class="fas fa-shield-halved"></i>
Quality products from WEAR ZONE
</div>

</div>

</div>

</div>

</main>

<script>

function increaseQty() {

    const input = document.getElementById("quantity");

    const current = parseInt(input.value);

    const max = parseInt(input.max);

    if (current < max) {
        input.value = current + 1;
    }
}

function decreaseQty() {

    const input = document.getElementById("quantity");

    const current = parseInt(input.value);

    if (current > 1) {
        input.value = current - 1;
    }
}

const sizeButtons = document.querySelectorAll(".size-btn");
const finalPrice = document.getElementById("finalPrice");
const oldPrice = document.getElementById("oldPrice");
const addCartBtn = document.getElementById("addCartBtn");

const discount = <?php echo $discount; ?>;

sizeButtons.forEach(function(button) {

    button.addEventListener("click", function() {

        sizeButtons.forEach(function(btn) {
            btn.classList.remove("active");
        });

        this.classList.add("active");

        const size = this.dataset.size;
        const price = parseFloat(this.dataset.price);

        let displayPrice = price;

        if (discount > 0) {

            displayPrice =
                price - ((price * discount) / 100);

            if (oldPrice) {
                oldPrice.textContent =
                    "₹" + price.toLocaleString("en-IN", {
                        minimumFractionDigits: 2
                    });
            }
        }

        if (finalPrice) {

            finalPrice.textContent =
                "₹" + displayPrice.toLocaleString("en-IN", {
                    minimumFractionDigits: 2
                });
        }

        if (addCartBtn) {

            addCartBtn.href =
                "add_to_cart.php?id=<?php echo $product_id; ?>&size=" +
                encodeURIComponent(size);
        }

    });

});

const wishlistBtn =
    document.getElementById("wishlistBtn");

if (wishlistBtn) {

    wishlistBtn.addEventListener("click", function() {

        const formData = new FormData();

        formData.append(
            "product_id",
            "<?php echo $product_id; ?>"
        );

        fetch("add_to_wishlist.php", {
            method: "POST",
            body: formData
        })
        .then(response => response.json())
        .then(data => {

            const heart =
                wishlistBtn.querySelector("i");

            if (data.status === "success") {

                heart.classList.remove("far");
                heart.classList.add("fas");

                alert("Product Added to Wishlist ❤️");

            } else if (data.status === "exists") {

                alert("Product already in Wishlist ❤️");

            } else if (data.status === "login") {

                window.location.href = "login.php";

            } else {

                alert(
                    data.message ||
                    "Something went wrong"
                );
            }

        })
        .catch(function() {
            alert("Something went wrong");
        });

    });
}

</script>
<?php if (isset($_GET['cart_added']) && $_GET['cart_added'] == '1') { ?>

<div id="cartMessage">
    ✓ Item added to cart
</div>

<script>
setTimeout(function() {
    var msg = document.getElementById("cartMessage");
    if (msg) {
        msg.style.display = "none";
    }
}, 2500);
</script>

<?php } ?>
</body>
</html>
```
