```php
<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

include("db.php");

$user_id = $_SESSION['user_id'];

$query = mysqli_query(
    $conn,
    "SELECT * FROM users WHERE id='$user_id'"
);

if (mysqli_num_rows($query) == 0) {
    echo "User not found";
    exit();
}

$user = mysqli_fetch_assoc($query);
?>

<!DOCTYPE html>
<html>

<head>

    <meta charset="UTF-8">

    <title>My Profile - WEAR ZONE</title>

    <style>

        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background: #f4f4f4;
        }

        .navbar {
            background: #111;
            padding: 18px 40px;
        }

        .navbar a {
            color: white;
            text-decoration: none;
            margin-right: 25px;
            font-size: 16px;
        }

        .navbar a:hover {
            color: red;
        }

        .container {
            width: 500px;
            margin: 50px auto;
            background: white;
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 5px 20px rgba(0,0,0,.15);
        }

        h2 {
            text-align: center;
            margin-bottom: 30px;
        }

        .profile-row {
            padding: 15px;
            border-bottom: 1px solid #ddd;
        }

        .profile-row:last-child {
            border-bottom: none;
        }

        .label {
            font-weight: bold;
            color: #555;
            display: block;
            margin-bottom: 5px;
        }

        .value {
            font-size: 17px;
            color: #111;
        }

        .edit-btn {
            display: block;
            text-align: center;
            background: #111;
            color: white;
            text-decoration: none;
            padding: 13px;
            margin-top: 25px;
            border-radius: 7px;
        }

        .edit-btn:hover {
            background: red;
        }

        .back-btn {
            display: block;
            text-align: center;
            margin-top: 15px;
            color: #555;
            text-decoration: none;
        }

    </style>

</head>

<body>

<!-- NAVBAR -->

<div class="navbar">

    <a href="index.php">🏠 Home</a>

    <a href="view_cart.php">🛒 Cart</a>

    <a href="my_orders.php">📦 My Orders</a>

    <a href="profile.php">👤 Profile</a>

    <a href="logout.php">🚪 Logout</a>

</div>


<!-- PROFILE -->

<div class="container">

    <h2>👤 My Profile</h2>


    <div class="profile-row">

        <span class="label">Name</span>

        <span class="value">
            <?php echo htmlspecialchars($user['username']); ?>
        </span>

    </div>


    <div class="profile-row">

        <span class="label">Email</span>

        <span class="value">
            <?php echo htmlspecialchars($user['email']); ?>
        </span>

    </div>


    <?php if (isset($user['mobile'])) { ?>

    <div class="profile-row">

        <span class="label">Mobile</span>

        <span class="value">
            <?php echo htmlspecialchars($user['mobile']); ?>
        </span>

    </div>

    <?php } ?>


    <?php if (isset($user['address'])) { ?>

    <div class="profile-row">

        <span class="label">Address</span>

        <span class="value">
            <?php echo htmlspecialchars($user['address']); ?>
        </span>

    </div>

    <?php } ?>


    <a href="edit_profile.php" class="edit-btn">
        ✏️ Edit Profile
    </a>

    <a href="index.php" class="back-btn">
        ← Back to Home
    </a>

</div>

</body>

</html>
```
