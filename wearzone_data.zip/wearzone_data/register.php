<?php
include 'db.php';

if(isset($_POST['register'])){
    $username=$_POST['username'];
    $email=$_POST['email'];
    $mobile=$_POST['mobile'];
    $password=$_POST['password'];
    $confirm_password=$_POST['confirm_password'];

    if($password!=$confirm_password){
        echo "<script>alert('Password and Confirm Password do not match!');window.location='register.php';</script>";
        exit();
    }

    $check=mysqli_query($conn,"SELECT * FROM users WHERE email='$email'");
    if(mysqli_num_rows($check)>0){
        echo "<script>alert('User already registered!');window.location='register.php';</script>";
        exit();
    }

    $hashed=password_hash($password,PASSWORD_DEFAULT);
    mysqli_query($conn,"INSERT INTO users(username,email,mobile,password) VALUES('$username','$email','$mobile','$hashed')");
    echo "<script>alert('Registration Successful!');window.location='login.php';</script>";
    exit();
}
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>Register</title>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&display=swap" rel="stylesheet">
<style>
*{margin:0;padding:0;box-sizing:border-box;font-family:Poppins,sans-serif}
body{min-height:100vh;display:flex;justify-content:center;align-items:center;background:linear-gradient(135deg,#4d6df3,#4169e1)}
.container{width:1100px;max-width:95%;display:flex;align-items:center;justify-content:space-between;gap:70px}
form{width:380px;background:#fff;padding:35px;border-radius:16px;box-shadow:0 20px 45px rgba(0,0,0,.2)}
h2{margin-bottom:20px;color:#222}
input{width:100%;padding:14px;margin:10px 0;border:1px solid #ddd;border-radius:8px;font-size:15px}
input:focus{outline:none;border-color:#4169e1;box-shadow:0 0 8px rgba(65,105,225,.25)}
button{width:100%;padding:14px;background:#4169e1;color:#fff;border:none;border-radius:8px;font-size:16px;font-weight:600;cursor:pointer}
button:hover{background:#3157cf}
.side{color:#fff}
.side h1{font-size:78px;line-height:1.05;font-weight:700}
.side p{margin-top:15px;font-size:18px;opacity:.9}
@media(max-width:900px){
.container{flex-direction:column;padding:20px}
.side h1{font-size:48px;text-align:center}
.side p{text-align:center}
}
</style>
</head>
<body>
<div class="container">
<form method="post">
<h2>Registration</h2>
<input type="text" name="username" placeholder="Enter your name" required>
<input type="email" name="email" placeholder="Enter your email" required>
<input type="tel" name="mobile" placeholder="Enter mobile number" maxlength="10" pattern="[0-9]{10}" required>
<input type="password" name="password" placeholder="Create password" required>
<input type="password" name="confirm_password" placeholder="Confirm password" required>
<button type="submit" name="register">Register Now</button>
<p style="margin-top:15px;text-align:center">Already have an account? <a href="login.php">Login now</a></p>
</form>
<div class="side">
<h1>Beautiful<br>Sign Up<br>Form</h1>
<p>Create your WearZone account and enjoy shopping.</p>
</div>
</div>
</body>
</html>
    