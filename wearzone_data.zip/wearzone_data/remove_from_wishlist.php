<?php

session_start();

include("db.php");


/* CHECK LOGIN */

if (!isset($_SESSION['user_id'])) {

    header("Location: login.php");
    exit();

}


$user_id = $_SESSION['user_id'];


/* CHECK WISHLIST ID */

if (!isset($_GET['id'])) {

    header("Location: wishlist.php");
    exit();

}


$wishlist_id = intval($_GET['id']);


/* DELETE ONLY USER'S OWN WISHLIST ITEM */

$sql = "
    DELETE FROM wishlist
    WHERE id = '$wishlist_id'
    AND user_id = '$user_id'
";


$result = mysqli_query($conn, $sql);


if ($result) {

    header("Location: wishlist.php");
    exit();

} else {

    echo "Error removing product from wishlist.";

}

?>