<?php

session_start();
include("db.php");

if(!isset($_SESSION['user_id']))
{
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

if(
    !isset($_POST['product_id']) ||
    !isset($_POST['rating']) ||
    !isset($_POST['review'])
)
{
    header("Location: index.php");
    exit();
}

$product_id = intval($_POST['product_id']);
$rating = intval($_POST['rating']);

$review = mysqli_real_escape_string(
    $conn,
    trim($_POST['review'])
);

if($rating < 1 || $rating > 5)
{
    echo "<script>
            alert('Please select a valid rating.');
            window.location='index.php';
          </script>";
    exit();
}

if($review == '')
{
    echo "<script>
            alert('Please write your review.');
            window.location='index.php';
          </script>";
    exit();
}

$sql = "INSERT INTO reviews
        (user_id, product_id, rating, review)
        VALUES
        ('$user_id', '$product_id', '$rating', '$review')";

if(mysqli_query($conn, $sql))
{
    echo "<script>
            alert('Review submitted successfully!');
            window.location='index.php';
          </script>";
    exit();
}
else
{
    echo "Error: " . mysqli_error($conn);
}

?>