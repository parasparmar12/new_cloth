<?php

session_start();
include("db.php");

if(!isset($_SESSION['user_id']))
{
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

$cart_id = $_GET['id'];
$action = $_GET['action'];

if($action == "increase")
{
    mysqli_query($conn,
        "UPDATE cart
         SET quantity = quantity + 1
         WHERE id='$cart_id' AND user_id='$user_id'"
    );
}

if($action == "decrease")
{
    mysqli_query($conn,
        "UPDATE cart
         SET quantity = quantity - 1
         WHERE id='$cart_id'
         AND user_id='$user_id'
         AND quantity > 1"
    );
}

header("Location: view_cart.php");
exit();

?>