<?php

session_start();
include("db.php");

if(!isset($_SESSION['user_id']))
{
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

$sql = mysqli_query(
    $conn,
    "SELECT cart.*, 
            products.product_name, 
            products.image
     FROM cart
     INNER JOIN products
     ON cart.product_id = products.id
     WHERE cart.user_id='$user_id'"
);

$coupon_error = $_SESSION['coupon_error'] ?? '';
$coupon_success = $_SESSION['coupon_success'] ?? '';

unset($_SESSION['coupon_error']);
unset($_SESSION['coupon_success']);

$grand_total = 0;
$coupon_discount = $_SESSION['coupon_discount'] ?? 0;

?>

<!DOCTYPE html>

<html>

<head>

<title>My Shopping Cart</title>

<style>

body{
    font-family:Arial, sans-serif;
    background:#f5f5f5;
    margin:0;
    padding:20px;
}

.container{
    width:90%;
    margin:auto;
}

h1{
    text-align:center;
    margin-bottom:30px;
}

table{
    width:100%;
    background:#fff;
    border-collapse:collapse;
    box-shadow:0 0 10px rgba(0,0,0,0.1);
}

th{
    background:#111;
    color:#fff;
    padding:15px;
    font-size:18px;
}

td{
    padding:15px;
    text-align:center;
    border-bottom:1px solid #ddd;
    font-size:16px;
}

img{
    width:80px;
    height:80px;
    object-fit:cover;
    border-radius:8px;
}

.size{
    font-weight:bold;
    background:#f1f1f1;
    padding:6px 12px;
    border-radius:5px;
    display:inline-block;
}

.qty-box{
    display:flex;
    justify-content:center;
    align-items:center;
    gap:10px;
}

.qty-btn{
    width:35px;
    height:35px;
    display:flex;
    justify-content:center;
    align-items:center;
    background:#111;
    color:#fff;
    text-decoration:none;
    border-radius:5px;
    font-size:22px;
    font-weight:bold;
}

.qty-btn:hover{
    background:#333;
}

.qty-number{
    min-width:25px;
    font-size:18px;
    font-weight:bold;
}

.btn{
    padding:10px 18px;
    background:#111;
    color:#fff;
    text-decoration:none;
    border-radius:6px;
    display:inline-block;
}

.remove{
    background:red;
}

.remove:hover{
    background:darkred;
}

.checkout{
    background:green;
}

.checkout:hover{
    background:darkgreen;
}

.bottom{
    margin-top:30px;
    display:flex;
    justify-content:space-between;
    align-items:center;
}

.bottom h2{
    margin:0;
}

.empty-cart{
    text-align:center;
    padding:40px;
    background:#fff;
    margin-top:20px;
    box-shadow:0 0 10px rgba(0,0,0,0.1);
}

.empty-cart h2{
    margin-bottom:20px;
}

.coupon-box{
    margin-top:25px;
    padding:20px;
    background:#fff;
    border-radius:10px;
    box-shadow:0 0 10px rgba(0,0,0,0.1);
}

.coupon-box h3{
    margin-top:0;
}

.coupon-box input{
    padding:12px;
    width:250px;
    border:1px solid #ccc;
    border-radius:6px;
    font-size:16px;
}

.coupon-box button{
    padding:12px 20px;
    background:#111;
    color:#fff;
    border:none;
    border-radius:6px;
    cursor:pointer;
}

.coupon-box button:hover{
    background:green;
}

@media(max-width:800px){

    .container{
        width:100%;
        overflow-x:auto;
    }

    table{
        min-width:800px;
    }

    .bottom{
        flex-direction:column;
        gap:20px;
        align-items:center;
    }

}

</style>

</head>

<body>

<div class="container">

<h1>🛒 My Shopping Cart</h1>

<?php

if(mysqli_num_rows($sql) > 0)
{

?>

<table>

<tr>

<th>Image</th>
<th>Product</th>
<th>Size</th>
<th>Price</th>
<th>Qty</th>
<th>Total</th>
<th>Action</th>

</tr>

<?php

while($row = mysqli_fetch_assoc($sql))
{

    $price = (float)$row['price'];
    $quantity = (int)$row['quantity'];

    $total = $price * $quantity;

    $grand_total += $total;

?>

<tr>

<td>

<img
src="uploads/<?php echo htmlspecialchars($row['image']); ?>"
alt="Product">

</td>

<td>

<?php echo htmlspecialchars($row['product_name']); ?>

</td>

<td>

<span class="size">

<?php echo htmlspecialchars($row['size'] ?? 'M'); ?>

</span>

</td>

<td>

₹<?php echo number_format($price, 2); ?>

</td>

<td>

<div class="qty-box">

<a
href="update_quantity.php?id=<?php echo $row['id']; ?>&action=decrease"
class="qty-btn">
− </a>

<span class="qty-number">

<?php echo $quantity; ?>

</span>

<a
href="update_quantity.php?id=<?php echo $row['id']; ?>&action=increase"
class="qty-btn">
+ </a>

</div>

</td>

<td>

₹<?php echo number_format($total, 2); ?>

</td>

<td>

<a
class="btn remove"
href="remove_cart.php?id=<?php echo $row['id']; ?>"
onclick="return confirm('Are you sure you want to remove this product?');">

Remove

</a>

</td>

</tr>

<?php

}

?>

</table>

<div class="coupon-box">

<h3>🎟️ Apply Coupon</h3>

<form action="apply_coupon.php" method="POST">

<input
type="text"
name="coupon_code"
placeholder="Enter Coupon Code"
required>

<button type="submit">
Apply Coupon
</button>

</form>

<?php if($coupon_error != '') { ?>

<p style="color:red;">
<?php echo htmlspecialchars($coupon_error); ?>
</p>

<?php } ?>

<?php if($coupon_success != '') { ?>

<p style="color:green;">
<?php echo htmlspecialchars($coupon_success); ?>
</p>

<?php } ?>

</div>

<div class="bottom">

<h2>

Grand Total :
₹<?php echo number_format(max(0, $grand_total - $coupon_discount), 2); ?>

</h2>

<div>

<a
class="btn"
href="index.php">

Continue Shopping

</a>

<a
class="btn checkout"
href="checkout.php">

Checkout

</a>

</div>

</div>

<?php

}

else

{

?>

<div class="empty-cart">

<h2>Your Cart is Empty 🛒</h2>

<a
class="btn"
href="index.php">

Continue Shopping

</a>

</div>

<?php

}

?>

</div>

</body>

</html>
