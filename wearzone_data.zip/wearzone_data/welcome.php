<?php
session_start();

if(!isset($_SESSION['username']))
{
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Welcome - WEAR ZONE</title>

<style>
*{
margin:0;
padding:0;
box-sizing:border-box;
font-family:'Poppins',sans-serif;
}

body{
height:100vh;
overflow:hidden;
display:flex;
justify-content:center;
align-items:center;
background:linear-gradient(-45deg,#0f2027,#203a43,#2c5364,#1f1c2c);
background-size:400% 400%;
animation:bg 10s ease infinite;
}

@keyframes bg{
0%{background-position:0% 50%;}
50%{background-position:100% 50%;}
100%{background-position:0% 50%;}
}

.card{
position:relative;
z-index:10;
text-align:center;
padding:50px;
background:rgba(255,255,255,.08);
backdrop-filter:blur(15px);
border-radius:20px;
box-shadow:0 0 40px rgba(0,0,0,.4);
animation:zoom 1s ease;
}

@keyframes zoom{
from{
transform:scale(.5);
opacity:0;
}
to{
transform:scale(1);
opacity:1;
}
}

h1{
font-size:55px;
color:#fff;
margin-bottom:15px;
}

h1 span{
color:#00ffd5;
}

p{
font-size:22px;
color:#fff;
}

.loader{
margin:30px auto;
width:220px;
height:8px;
background:#555;
border-radius:20px;
overflow:hidden;
}

.bar{
height:100%;
width:0%;
background:#00ffd5;
animation:load 8s linear forwards;
}

@keyframes load{
100%{
width:100%;
}
}

.circle{
position:absolute;
border-radius:50%;
background:rgba(255,255,255,.2);
animation:float 15s linear infinite;
}

@keyframes float{
0%{
transform:translateY(100vh) scale(0);
}
100%{
transform:translateY(-120vh) scale(1);
}
}

canvas{
position:absolute;
top:0;
left:0;
}
</style>
</head>

<body>

<canvas id="canvas"></canvas>

<div class="card">
<h1>WELCOME <span><?php echo $_SESSION['username']; ?></span></h1>

<p>Successfully Logged into <b>WEAR ZONE</b></p>

<div class="loader">
<div class="bar"></div>
</div>

<p>Redirecting...</p>

</div>

<script>
for(let i=0;i<40;i++)
{
let c=document.createElement("div");
c.className="circle";
c.style.left=Math.random()*100+"%";
c.style.width=c.style.height=(20+Math.random()*60)+"px";
c.style.animationDuration=(8+Math.random()*8)+"s";
document.body.appendChild(c);
}
</script>

<script>
const canvas=document.getElementById("canvas");
const ctx=canvas.getContext("2d");

canvas.width=window.innerWidth;
canvas.height=window.innerHeight;

let fireworks=[];

function Firework(){
this.x=Math.random()*canvas.width;
this.y=canvas.height;
this.tx=Math.random()*canvas.width;
this.ty=Math.random()*canvas.height/2;
this.particles=[];
this.exploded=false;
}

Firework.prototype.update=function(){

if(!this.exploded){

this.x+=(this.tx-this.x)*0.05;
this.y+=(this.ty-this.y)*0.05;

ctx.beginPath();
ctx.arc(this.x,this.y,3,0,Math.PI*2);
ctx.fillStyle="white";
ctx.fill();

if(Math.abs(this.x-this.tx)<5 && Math.abs(this.y-this.ty)<5){

this.exploded=true;

for(let i=0;i<80;i++){

this.particles.push({
x:this.tx,
y:this.ty,
dx:(Math.random()-0.5)*8,
dy:(Math.random()-0.5)*8,
life:100
});

}

}

}
else{

this.particles.forEach(p=>{

p.x+=p.dx;
p.y+=p.dy;
p.life--;

ctx.fillStyle=`hsl(${Math.random()*360},100%,50%)`;
ctx.fillRect(p.x,p.y,3,3);

});

this.particles=this.particles.filter(p=>p.life>0);

}

}

setInterval(()=>{

fireworks.push(new Firework());

},700);

function animate(){

ctx.clearRect(0,0,canvas.width,canvas.height);

fireworks.forEach(f=>f.update());

requestAnimationFrame(animate);

}

animate();

setTimeout(function(){

window.location="index.php";

},5000);

</script>

</body>
</html>