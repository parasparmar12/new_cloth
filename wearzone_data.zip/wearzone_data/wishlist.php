<?php

session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

include("db.php");

$user_id = $_SESSION['user_id'];


/* GET WISHLIST PRODUCTS */

$sql = "
    SELECT
        wishlist.id AS wishlist_id,
        products.id AS product_id,
        products.product_name,
        products.category,
        products.price,
        products.stock,
        products.image
    FROM wishlist
    INNER JOIN products
        ON wishlist.product_id = products.id
    WHERE wishlist.user_id = '$user_id'
    ORDER BY wishlist.id DESC
";

$result = mysqli_query($conn, $sql);

?>

<!DOCTYPE html>

<html>

<head>

    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>My Wishlist - WEAR ZONE</title>

    <style>

        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background: #f4f4f4;
        }


        /* NAVBAR */

        .navbar {
            background: #111;
            padding: 18px 40px;
        }

        .navbar a {
            color: white;
            text-decoration: none;
            margin-right: 25px;
            font-size: 16px;
        }

        .navbar a:hover {
            color: red;
        }


        /* MAIN */

        .container {
            width: 90%;
            margin: 40px auto;
        }


        h2 {
            text-align: center;
            margin-bottom: 30px;
        }


        /* PRODUCT GRID */

        .wishlist-container {

            display: grid;

            grid-template-columns:
                repeat(auto-fit, minmax(220px, 1fr));

            gap: 25px;
        }


        /* PRODUCT CARD */

        .product-card {

            background: white;

            padding: 20px;

            border-radius: 12px;

            box-shadow:
                0 5px 15px rgba(0,0,0,.12);

            text-align: center;
        }


        .product-card img {

            width: 100%;

            height: 220px;

            object-fit:  contain;

            border-radius: 8px;
        }


        .product-card h3 {

            margin: 15px 0 8px;
        }


        .category {

            color: #777;

            margin: 5px 0;
        }


        .price {

            font-size: 20px;

            font-weight: bold;

            margin: 10px 0;
        }


        .stock {

            color: #555;

            margin-bottom: 15px;
        }


        /* BUTTONS */

        .btn {

            display: block;

            text-decoration: none;

            padding: 11px;

            border-radius: 6px;

            margin-top: 10px;

            color: white;
        }


        .cart-btn {

            background: #111;
        }


        .cart-btn:hover {

            background: green;
        }


        .remove-btn {

            background: red;
        }


        .remove-btn:hover {

            background: darkred;
        }


        /* EMPTY WISHLIST */

        .empty {

            background: white;

            padding: 40px;

            text-align: center;

            border-radius: 12px;

            box-shadow:
                0 5px 15px rgba(0,0,0,.1);
        }


        .shop-btn {

            display: inline-block;

            background: #111;

            color: white;

            padding: 12px 25px;

            text-decoration: none;

            border-radius: 6px;

            margin-top: 15px;
        }


        .shop-btn:hover {

            background: red;
        }

    </style>

</head>


<body>


<!-- NAVBAR -->

<div class="navbar">

    <a href="index.php">
        🏠 Home
    </a>

    <a href="wishlist.php">
        ❤️ Wishlist
    </a>

    <a href="view_cart.php">
        🛒 Cart
    </a>

    <a href="profile.php">
        👤 Profile
    </a>

    <a href="my_orders.php">
        📦 My Orders
    </a>

    <a href="logout.php">
        🚪 Logout
    </a>

</div>


<!-- MAIN -->

<div class="container">

    <h2>
        ❤️ My Wishlist
    </h2>


    <?php

    if (mysqli_num_rows($result) > 0) {

    ?>

        <div class="wishlist-container">


        <?php

        while ($row = mysqli_fetch_assoc($result)) {

        ?>


            <div class="product-card">


                <!-- IMAGE -->

                <img
                    src="uploads/<?php echo htmlspecialchars($row['image']); ?>"
                    alt="Product Image">


                <!-- NAME -->

                <h3>

                    <?php
                    echo htmlspecialchars(
                        $row['product_name']
                    );
                    ?>

                </h3>


                <!-- CATEGORY -->

                <p class="category">

                    <?php
                    echo htmlspecialchars(
                        $row['category']
                    );
                    ?>

                </p>


                <!-- PRICE -->

                <p class="price">

                    ₹<?php
                    echo htmlspecialchars(
                        $row['price']
                    );
                    ?>

                </p>


                <!-- STOCK -->

                <p class="stock">

                    Stock :
                    <?php
                    echo htmlspecialchars(
                        $row['stock']
                    );
                    ?>

                </p>


                <?php

                if ($row['stock'] > 0) {

                ?>

                    <!-- ADD TO CART -->

                    <a
                        href="add_to_cart.php?id=<?php echo $row['product_id']; ?>"
                        class="btn cart-btn">

                        🛒 Add To Cart

                    </a>

                <?php

                } else {

                ?>

                    <p style="color:red;">
                        Out of Stock
                    </p>

                <?php

                }

                ?>


                <!-- REMOVE -->

                <a
                    href="remove_from_wishlist.php?id=<?php echo $row['wishlist_id']; ?>"
                    class="btn remove-btn"
                    onclick="return confirm('Remove this product from Wishlist?');">

                    🗑️ Remove

                </a>


            </div>


        <?php

        }

        ?>


        </div>


    <?php

    } else {

    ?>


        <div class="empty">

            <h3>
                ❤️ Your Wishlist is Empty
            </h3>

            <p>
                Add your favorite products to Wishlist.
            </p>

            <a
                href="index.php"
                class="shop-btn">

                🛍️ Continue Shopping

            </a>

        </div>


    <?php

    }

    ?>

</div>


</body>

</html>
```
